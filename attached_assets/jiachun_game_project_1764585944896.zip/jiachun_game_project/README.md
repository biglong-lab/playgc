# 賈村競技體驗場 - 實境遊戲系統開發專案

- **專案目標**: 為賈村競技體驗場打造一套功能完整的實境遊戲開發與管理系統。
- **開發平台**: Replit (用於快速原型開發與協作)
- **主要技術**: React, Vite, Supabase, Tailwind CSS, MQTT, Arduino
- **版本**: 1.0

## 專案概述

本專案旨在開發一套專為**賈村競技體驗場**設計的實境遊戲系統。此系統讓遊戲設計者能透過視覺化的編輯器,輕鬆創建結合**射擊**、**拍照**、**GPS定位**、**即時通訊**及 **Arduino 設備互動**的沉浸式遊戲體驗。

### 核心功能

- **視覺化遊戲編輯器**: 拖曳式頁面模組,無需編程即可設計遊戲流程。
- **多元互動機制**: 整合 GPS 定位、QR Code 掃描、拍照任務、文字與選擇驗證。
- **即時競技元素**: 包含即時團隊聊天、積分系統與排行榜。
- **硬體整合 (IoT)**: 透過 MQTT 協定串接 Arduino 設備,如射擊靶機、感應器、燈光等,實現線上線下(OMO)的深度互動。

## Replit 開發環境設定

### 1. 專案初始化

1.  **Fork this Replit**: 點擊右上角的 "Fork" 按鈕,將此專案複製到您自己的 Replit 帳號。
2.  **開啟 Shell**: 在 Replit 右側工具欄中選擇 "Shell"。
3.  **安裝依賴**: 在 Shell 中執行以下指令安裝所需套件。
    ```bash
    npm install
    ```

### 2. 設定環境變數

1.  **取得 Supabase 金鑰**: 
    - 前往 [Supabase](https://supabase.com/) 註冊並創建一個新專案。
    - 進入專案儀表板,在 `Settings` > `API` 中找到您的 `Project URL` 和 `anon` `public` 金鑰。

2.  **設定 Replit Secrets**:
    - 在 Replit 左側工具欄中選擇 "Secrets"。
    - 新增以下環境變數:

| Key | Value | 說明 |
| :--- | :--- | :--- |
| `VITE_SUPABASE_URL` | `your_supabase_project_url` | 您的 Supabase 專案 URL |
| `VITE_SUPABASE_ANON_KEY` | `your_supabase_anon_key` | 您的 Supabase anon public 金鑰 |
| `VITE_MQTT_BROKER` | `wss://broker.hivemq.com:8884/mqtt` | 公開的 MQTT Broker (用於測試) |

### 3. 啟動專案

- **執行開發伺服器**: 在 Shell 中執行以下指令。
  ```bash
  npm run dev
  ```
- **預覽**: Replit 會自動開啟一個 WebView 來預覽您的應用程式。您也可以在新分頁中開啟公開的 URL。

## 後端設定 (Supabase)

### 1. 資料庫結構

- 前往 Supabase 儀表板的 `SQL Editor`。
- 複製並執行 `DATABASE_SCHEMA.sql` 文件中的所有 SQL 指令,以建立所需的資料表與索引。

### 2. 身份驗證 (Authentication)

- 前往 `Authentication` > `Providers`。
- 啟用 `Email` 提供者。您可以根據需求啟用其他第三方登入,如 Google 或 LINE。
- 前往 `Authentication` > `Settings`,關閉 `Enable email confirmation` 以簡化開發流程(生產環境建議開啟)。

### 3. 檔案儲存 (Storage)

- 前往 `Storage`。
- 創建一個名為 `game-assets` 的 **Public Bucket**, 用於存放遊戲封面、道具圖示等公開資源。
- 創建一個名為 `game-uploads` 的 **Private Bucket**, 用於存放玩家上傳的照片等私密檔案。
- 為 `game-uploads` 設定儲存策略 (Policies),確保只有對應的玩家可以存取自己的檔案。

```sql
-- 允許玩家上傳檔案到自己的資料夾
CREATE POLICY "Allow user uploads" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'game-uploads' AND (storage.foldername(name))[1] = auth.uid()::text);

-- 允許玩家讀取自己上傳的檔案
CREATE POLICY "Allow user reads" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'game-uploads' AND (storage.foldername(name))[1] = auth.uid()::text);
```

## 專案文件

本專案包含以下詳細的規格文件,請在開發前詳細閱讀:

- **[GAME_ARCHITECTURE.md](./GAME_ARCHITECTURE.md)**: 遊戲功能架構設計,包含核心特色、應用場景、系統架構圖、資料庫設計與頁面模組規格。

- **[TECHNICAL_SPEC.md](./TECHNICAL_SPEC.md)**: 詳細技術實作規格,包含前端技術細節、後端 RLS 策略、地圖服務、圖片處理、Arduino 串接完整方案、效能優化與安全性考量。

- **[UI_UX_DESIGN.md](./UI_UX_DESIGN.md)**: 完整的使用者介面與體驗設計規格,包含設計理念、色彩系統、字體、組件設計、頁面佈局與動畫效果。

- **[DATABASE_SCHEMA.sql](./DATABASE_SCHEMA.sql)**: 完整的資料庫建立指令碼。

## 專案結構

```
/jiachun_game_project
├── src/
│   ├── components/       # React 組件
│   │   ├── common/       # 通用組件 (Button, Card, Input)
│   │   ├── game/         # 遊戲頁面組件 (MapView, DialogueBubble)
│   │   └── admin/        # 後台管理組件 (GameEditor, DeviceStatus)
│   ├── pages/            # 頁面級組件
│   │   ├── Player/       # 玩家端頁面
│   │   └── Admin/        # 管理端頁面
│   ├── hooks/            # 自定義 React Hooks (usePlayerLocation, useGameSession)
│   ├── services/         # 服務層 (supabase.js, mqtt.js)
│   ├── stores/           # 狀態管理 (Zustand stores)
│   ├── utils/            # 工具函數
│   ├── App.jsx           # 主應用組件
│   └── main.jsx          # 應用程式進入點
├── public/               # 靜態資源 (圖示、字體)
├── assets/
│   └── reference_images/ # 參考圖片
├── .env.example          # 環境變數範例
├── package.json          # 專案依賴
├── tailwind.config.js    # Tailwind CSS 設定
├── README.md             # 專案主說明文件 (本文件)
├── GAME_ARCHITECTURE.md  # 遊戲架構設計文件
├── TECHNICAL_SPEC.md     # 技術實作規格文件
├── UI_UX_DESIGN.md       # 視覺設計規格文件
└── DATABASE_SCHEMA.sql   # 資料庫結構文件
```

## 開發流程建議

1.  **設定環境**: 完成 Replit 與 Supabase 的設定。
2.  **建立資料庫**: 執行 `DATABASE_SCHEMA.sql`。
3.  **開發核心功能**: 從玩家端的身份驗證、遊戲大廳開始。
4.  **實作頁面模組**: 根據 `UI_UX_DESIGN.md` 逐一開發各個頁面模組的 React 組件。
5.  **串接後端邏輯**: 將組件與 Supabase API 串接,實現遊戲進度存取。
6.  **整合互動功能**: 實作地圖、拍照、即時聊天等功能。
7.  **開發 Arduino 端**: 根據 `TECHNICAL_SPEC.md` 中的程式碼範例,開發 Arduino 設備的韌體。
8.  **整合 MQTT**: 在前端與 Arduino 端實現 MQTT 通訊,完成硬體整合。
9.  **開發後台管理**: 實作遊戲編輯器與數據儀表板。
10. **測試與部署**: 進行完整測試,並可考慮將前端部署至 Vercel 以獲得更好的效能。

## 聯絡與支援

- **專案規劃師**: Manus AI
- **問題回報**: 若在開發過程中遇到任何與本規格文件相關的問題,請直接回覆。
