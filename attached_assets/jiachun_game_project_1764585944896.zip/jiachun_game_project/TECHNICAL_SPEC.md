# 技術實作規格書

## 1. 技術堆疊詳細說明

### 1.1 前端技術

#### React + Vite
- **版本**: React 18+ with Vite 5+
- **優勢**: 快速的 HMR (熱模組替換)、優化的打包、現代化的開發體驗
- **專案結構**:
```
src/
├── components/          # 可重用組件
│   ├── common/         # 通用組件 (Button, Input, Modal)
│   ├── game/           # 遊戲相關組件
│   └── admin/          # 後台管理組件
├── pages/              # 頁面組件
│   ├── Player/         # 玩家端頁面
│   └── Admin/          # 管理端頁面
├── hooks/              # 自定義 Hooks
├── utils/              # 工具函數
├── services/           # API 服務
└── stores/             # 狀態管理
```

#### Tailwind CSS + DaisyUI
- **Tailwind CSS 3.4+**: 實用優先的 CSS 框架
- **DaisyUI 4.0+**: 基於 Tailwind 的組件庫
- **客製化主題**:
```javascript
// tailwind.config.js
module.exports = {
  daisyui: {
    themes: [
      {
        jiachun: {
          "primary": "#d97706",      // 軍事橘
          "secondary": "#059669",    // 戰術綠
          "accent": "#dc2626",       // 警示紅
          "neutral": "#374151",      // 深灰
          "base-100": "#1f2937",     // 深色背景
        },
      },
    ],
  },
}
```

### 1.2 後端服務 - Supabase

#### PostgreSQL 資料庫
- **版本**: PostgreSQL 15+
- **擴充功能**:
  - `uuid-ossp`: UUID 生成
  - `postgis`: 地理空間數據支援
  - `pg_cron`: 定時任務

#### Row Level Security (RLS) 設定

```sql
-- 遊戲表: 創建者可完全控制,其他人只能讀取已發布的遊戲
ALTER TABLE games ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view published games"
  ON games FOR SELECT
  USING (status = 'published' OR creator_id = auth.uid());

CREATE POLICY "Users can manage their own games"
  ON games FOR ALL
  USING (creator_id = auth.uid());

-- 遊戲場次: 參與者可讀取,系統可寫入
CREATE POLICY "Players can view their sessions"
  ON game_sessions FOR SELECT
  USING (
    id IN (
      SELECT session_id FROM player_progress 
      WHERE user_id = auth.uid()
    )
  );
```

#### Supabase Realtime 配置

```javascript
// 啟用 Realtime
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// 訂閱聊天訊息
const chatChannel = supabase
  .channel('chat_room')
  .on('postgres_changes', {
    event: 'INSERT',
    schema: 'public',
    table: 'chat_messages',
    filter: `session_id=eq.${sessionId}`
  }, handleNewMessage)
  .subscribe()

// 訂閱玩家位置更新
const locationChannel = supabase
  .channel('player_locations')
  .on('presence', { event: 'sync' }, () => {
    const state = locationChannel.presenceState()
    updatePlayerMarkers(state)
  })
  .subscribe()
```

### 1.3 地圖服務 - Leaflet.js

#### 基礎配置
```javascript
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'

// 初始化地圖 (賈村競技場座標)
const map = L.map('map').setView([25.0330, 121.5654], 18)

// 使用 OpenStreetMap 圖層
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '© OpenStreetMap contributors',
  maxZoom: 19
}).addTo(map)

// 自定義標記圖示
const targetIcon = L.icon({
  iconUrl: '/icons/target.png',
  iconSize: [32, 32],
  iconAnchor: [16, 32]
})

// 添加任務點標記
L.marker([25.0330, 121.5654], { icon: targetIcon })
  .bindPopup('射擊點 A')
  .addTo(map)
```

#### 玩家即時定位
```javascript
// 獲取玩家位置
function trackPlayerLocation() {
  if ("geolocation" in navigator) {
    navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude } = position.coords
        updatePlayerMarker(latitude, longitude)
        checkProximityToTargets(latitude, longitude)
      },
      (error) => console.error('定位錯誤:', error),
      { enableHighAccuracy: true, maximumAge: 5000 }
    )
  }
}

// 檢查是否接近目標點
function checkProximityToTargets(lat, lng) {
  targets.forEach(target => {
    const distance = calculateDistance(lat, lng, target.lat, target.lng)
    if (distance < target.radius) {
      triggerLocationEvent(target.id)
    }
  })
}
```

### 1.4 圖片處理

#### 拍照與上傳
```javascript
import Compressor from 'compressorjs'

// 拍照功能
async function capturePhoto() {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = 'image/*'
  input.capture = 'environment' // 使用後置鏡頭
  
  input.onchange = async (e) => {
    const file = e.target.files[0]
    const compressed = await compressImage(file)
    await uploadPhoto(compressed)
  }
  
  input.click()
}

// 圖片壓縮
function compressImage(file) {
  return new Promise((resolve, reject) => {
    new Compressor(file, {
      quality: 0.8,
      maxWidth: 1920,
      maxHeight: 1920,
      success: resolve,
      error: reject
    })
  })
}

// 上傳至 Supabase Storage
async function uploadPhoto(file) {
  const fileName = `${Date.now()}_${file.name}`
  const { data, error } = await supabase.storage
    .from('game-photos')
    .upload(`session_${sessionId}/${fileName}`, file)
  
  if (error) throw error
  return data.path
}
```

#### AI 圖片辨識 (可選)
```javascript
// 使用 TensorFlow.js 進行簡單的物體辨識
import * as mobilenet from '@tensorflow-models/mobilenet'

async function verifyPhoto(imageElement, targetKeywords) {
  const model = await mobilenet.load()
  const predictions = await model.classify(imageElement)
  
  // 檢查辨識結果是否包含目標關鍵字
  const match = predictions.some(pred => 
    targetKeywords.some(keyword => 
      pred.className.toLowerCase().includes(keyword.toLowerCase())
    )
  )
  
  return match
}
```

## 2. Arduino 設備串接詳細方案

### 2.1 MQTT 架構

#### 使用 HiveMQ Cloud (免費方案)
- **連線數**: 最多 100 個同時連線
- **訊息量**: 每月 10GB
- **延遲**: < 100ms

#### MQTT Broker 設定
```javascript
// 前端 MQTT 客戶端 (使用 MQTT.js)
import mqtt from 'mqtt'

const client = mqtt.connect('wss://broker.hivemq.com:8884/mqtt', {
  clientId: `jiachun_web_${Math.random().toString(16).slice(3)}`,
  clean: true,
  connectTimeout: 4000,
  reconnectPeriod: 1000,
})

client.on('connect', () => {
  console.log('MQTT 已連線')
  
  // 訂閱設備數據主題
  client.subscribe('jiachun/devices/+/data')
  client.subscribe(`jiachun/sessions/${sessionId}/events`)
})

client.on('message', (topic, message) => {
  const data = JSON.parse(message.toString())
  handleDeviceData(topic, data)
})
```

### 2.2 射擊靶機整合

#### Arduino 硬體需求
- **主控板**: ESP32 DevKit (支援 WiFi)
- **感應器**: 紅外線感應器或壓力感應器
- **指示燈**: WS2812B LED 燈條
- **電源**: 12V 電源供應器

#### Arduino 完整程式碼
```cpp
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <Adafruit_NeoPixel.h>

// WiFi 設定
const char* ssid = "JiachunField_WiFi";
const char* password = "your_password";

// MQTT 設定
const char* mqtt_server = "broker.hivemq.com";
const int mqtt_port = 1883;
const char* device_id = "target_001";

// 硬體設定
#define HIT_SENSOR_PIN 34
#define LED_PIN 5
#define LED_COUNT 12

WiFiClient espClient;
PubSubClient client(espClient);
Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);

// 狀態變數
bool isActive = false;
int hitCount = 0;
unsigned long lastHitTime = 0;

void setup() {
  Serial.begin(115200);
  
  // 初始化感應器
  pinMode(HIT_SENSOR_PIN, INPUT);
  
  // 初始化 LED
  strip.begin();
  strip.show();
  
  // 連接 WiFi
  setupWiFi();
  
  // 連接 MQTT
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqttCallback);
}

void setupWiFi() {
  Serial.print("連接 WiFi: ");
  Serial.println(ssid);
  
  WiFi.begin(ssid, password);
  
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  
  Serial.println("\nWiFi 已連線");
  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

void reconnectMQTT() {
  while (!client.connected()) {
    Serial.print("連接 MQTT...");
    
    String clientId = "jiachun_" + String(device_id);
    
    if (client.connect(clientId.c_str())) {
      Serial.println("已連線");
      
      // 訂閱控制主題
      String commandTopic = "jiachun/devices/" + String(device_id) + "/command";
      client.subscribe(commandTopic.c_str());
      
      // 發送上線通知
      publishStatus("online");
    } else {
      Serial.print("失敗, rc=");
      Serial.println(client.state());
      delay(5000);
    }
  }
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message = "";
  for (int i = 0; i < length; i++) {
    message += (char)payload[i];
  }
  
  Serial.print("收到訊息: ");
  Serial.println(message);
  
  // 解析 JSON
  StaticJsonDocument<200> doc;
  deserializeJson(doc, message);
  
  String command = doc["command"];
  
  if (command == "activate") {
    isActive = true;
    hitCount = 0;
    setLEDColor(0, 255, 0); // 綠色表示啟動
    Serial.println("靶機已啟動");
  }
  else if (command == "deactivate") {
    isActive = false;
    setLEDColor(255, 0, 0); // 紅色表示停用
    Serial.println("靶機已停用");
  }
  else if (command == "reset") {
    hitCount = 0;
    Serial.println("計數已重置");
  }
}

void loop() {
  if (!client.connected()) {
    reconnectMQTT();
  }
  client.loop();
  
  // 檢測命中
  if (isActive && detectHit()) {
    handleHit();
  }
  
  // 定期發送心跳
  static unsigned long lastHeartbeat = 0;
  if (millis() - lastHeartbeat > 30000) {
    publishHeartbeat();
    lastHeartbeat = millis();
  }
}

bool detectHit() {
  // 讀取感應器
  int sensorValue = analogRead(HIT_SENSOR_PIN);
  
  // 防止重複觸發 (500ms 內只記錄一次)
  if (sensorValue > 2000 && millis() - lastHitTime > 500) {
    lastHitTime = millis();
    return true;
  }
  
  return false;
}

void handleHit() {
  hitCount++;
  
  // 計算分數 (根據命中位置)
  int score = calculateScore();
  
  // LED 閃爍效果
  flashLED(255, 255, 0); // 黃色閃爍
  
  // 發送命中數據
  publishHitData(score);
  
  Serial.print("命中! 分數: ");
  Serial.println(score);
}

int calculateScore() {
  // 簡化版: 根據感應器數值計算分數
  int sensorValue = analogRead(HIT_SENSOR_PIN);
  
  if (sensorValue > 3500) return 10; // 靶心
  if (sensorValue > 3000) return 8;
  if (sensorValue > 2500) return 5;
  return 3;
}

void publishHitData(int score) {
  StaticJsonDocument<200> doc;
  doc["device_id"] = device_id;
  doc["hit"] = true;
  doc["score"] = score;
  doc["hit_count"] = hitCount;
  doc["timestamp"] = millis();
  
  String output;
  serializeJson(doc, output);
  
  String topic = "jiachun/devices/" + String(device_id) + "/data";
  client.publish(topic.c_str(), output.c_str());
}

void publishStatus(String status) {
  StaticJsonDocument<200> doc;
  doc["device_id"] = device_id;
  doc["status"] = status;
  doc["timestamp"] = millis();
  
  String output;
  serializeJson(doc, output);
  
  String topic = "jiachun/devices/" + String(device_id) + "/status";
  client.publish(topic.c_str(), output.c_str());
}

void publishHeartbeat() {
  StaticJsonDocument<200> doc;
  doc["device_id"] = device_id;
  doc["heartbeat"] = true;
  doc["hit_count"] = hitCount;
  doc["uptime"] = millis() / 1000;
  
  String output;
  serializeJson(doc, output);
  
  String topic = "jiachun/devices/" + String(device_id) + "/status";
  client.publish(topic.c_str(), output.c_str());
}

void setLEDColor(uint8_t r, uint8_t g, uint8_t b) {
  for(int i=0; i<strip.numPixels(); i++) {
    strip.setPixelColor(i, strip.Color(r, g, b));
  }
  strip.show();
}

void flashLED(uint8_t r, uint8_t g, uint8_t b) {
  for(int i=0; i<3; i++) {
    setLEDColor(r, g, b);
    delay(100);
    setLEDColor(0, 0, 0);
    delay(100);
  }
}
```

### 2.3 其他感應器整合

#### 動作感應器 (PIR Sensor)
```cpp
#define PIR_PIN 33

void setup() {
  pinMode(PIR_PIN, INPUT);
}

void loop() {
  if (digitalRead(PIR_PIN) == HIGH) {
    publishMotionDetected();
    delay(2000); // 防止重複觸發
  }
}

void publishMotionDetected() {
  StaticJsonDocument<200> doc;
  doc["device_id"] = device_id;
  doc["event"] = "motion_detected";
  doc["timestamp"] = millis();
  
  String output;
  serializeJson(doc, output);
  
  String topic = "jiachun/devices/" + String(device_id) + "/data";
  client.publish(topic.c_str(), output.c_str());
}
```

#### RFID 讀卡機 (RC522)
```cpp
#include <SPI.h>
#include <MFRC522.h>

#define RST_PIN 22
#define SS_PIN 21

MFRC522 mfrc522(SS_PIN, RST_PIN);

void setup() {
  SPI.begin();
  mfrc522.PCD_Init();
}

void loop() {
  if (mfrc522.PICC_IsNewCardPresent() && mfrc522.PICC_ReadCardSerial()) {
    String cardID = getCardID();
    publishCardDetected(cardID);
    mfrc522.PICC_HaltA();
  }
}

String getCardID() {
  String content = "";
  for (byte i = 0; i < mfrc522.uid.size; i++) {
    content += String(mfrc522.uid.uidByte[i], HEX);
  }
  content.toUpperCase();
  return content;
}

void publishCardDetected(String cardID) {
  StaticJsonDocument<200> doc;
  doc["device_id"] = device_id;
  doc["event"] = "card_detected";
  doc["card_id"] = cardID;
  doc["timestamp"] = millis();
  
  String output;
  serializeJson(doc, output);
  
  String topic = "jiachun/devices/" + String(device_id) + "/data";
  client.publish(topic.c_str(), output.c_str());
}
```

## 3. 前端狀態管理

### 使用 Zustand
```javascript
import create from 'zustand'

// 遊戲狀態
export const useGameStore = create((set, get) => ({
  // 狀態
  currentSession: null,
  currentPage: null,
  inventory: [],
  variables: {},
  score: 0,
  
  // Actions
  setCurrentPage: (page) => set({ currentPage: page }),
  
  addItem: (item) => set((state) => ({
    inventory: [...state.inventory, item]
  })),
  
  removeItem: (itemId) => set((state) => ({
    inventory: state.inventory.filter(i => i.id !== itemId)
  })),
  
  updateVariable: (key, value) => set((state) => ({
    variables: { ...state.variables, [key]: value }
  })),
  
  addScore: (points) => set((state) => ({
    score: state.score + points
  })),
  
  // 保存進度到 Supabase
  saveProgress: async () => {
    const state = get()
    await supabase.from('player_progress').upsert({
      session_id: state.currentSession.id,
      user_id: state.currentSession.user_id,
      current_page_id: state.currentPage?.id,
      inventory: state.inventory,
      variables: state.variables
    })
  }
}))
```

## 4. 效能優化

### 4.1 圖片優化
- 使用 WebP 格式
- 實作 lazy loading
- 使用 Supabase Image Transformation

```javascript
// 生成優化的圖片 URL
function getOptimizedImageUrl(path, width = 800) {
  const { data } = supabase.storage
    .from('game-photos')
    .getPublicUrl(path, {
      transform: {
        width: width,
        quality: 80,
        format: 'webp'
      }
    })
  return data.publicUrl
}
```

### 4.2 資料庫查詢優化
```sql
-- 為常用查詢建立索引
CREATE INDEX idx_pages_game_id ON pages(game_id);
CREATE INDEX idx_pages_order ON pages(game_id, page_order);
CREATE INDEX idx_sessions_status ON game_sessions(status, started_at);
CREATE INDEX idx_leaderboard_game ON leaderboard(game_id, total_score DESC);

-- 使用 Materialized View 加速排行榜查詢
CREATE MATERIALIZED VIEW daily_leaderboard AS
SELECT 
  game_id,
  team_name,
  total_score,
  completion_time,
  ROW_NUMBER() OVER (PARTITION BY game_id ORDER BY total_score DESC) as rank
FROM leaderboard
WHERE created_at >= CURRENT_DATE;

-- 定時更新
SELECT cron.schedule('refresh-leaderboard', '*/5 * * * *', 
  'REFRESH MATERIALIZED VIEW daily_leaderboard');
```

### 4.3 前端快取策略
```javascript
// 使用 React Query 進行數據快取
import { useQuery } from '@tanstack/react-query'

function useGameData(gameId) {
  return useQuery({
    queryKey: ['game', gameId],
    queryFn: async () => {
      const { data } = await supabase
        .from('games')
        .select('*, pages(*)')
        .eq('id', gameId)
        .single()
      return data
    },
    staleTime: 5 * 60 * 1000, // 5分鐘內不重新獲取
    cacheTime: 30 * 60 * 1000, // 快取保留30分鐘
  })
}
```

## 5. 安全性考量

### 5.1 API 安全
```javascript
// Supabase Edge Function 驗證請求
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

serve(async (req) => {
  // 驗證 JWT Token
  const authHeader = req.headers.get('Authorization')
  if (!authHeader) {
    return new Response('Unauthorized', { status: 401 })
  }
  
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL'),
    Deno.env.get('SUPABASE_ANON_KEY'),
    { global: { headers: { Authorization: authHeader } } }
  )
  
  const { data: { user }, error } = await supabase.auth.getUser()
  if (error || !user) {
    return new Response('Unauthorized', { status: 401 })
  }
  
  // 處理請求...
})
```

### 5.2 防作弊機制
```javascript
// 伺服器端驗證分數
async function validateScore(sessionId, claimedScore) {
  // 獲取該場次的所有射擊記錄
  const { data: records } = await supabase
    .from('shooting_records')
    .select('hit_score')
    .eq('session_id', sessionId)
  
  // 計算實際分數
  const actualScore = records.reduce((sum, r) => sum + r.hit_score, 0)
  
  // 允許 5% 的誤差
  if (Math.abs(claimedScore - actualScore) > actualScore * 0.05) {
    console.warn('分數異常:', { claimed: claimedScore, actual: actualScore })
    return actualScore
  }
  
  return claimedScore
}
```

## 6. 部署與維運

### 6.1 Replit 部署
```bash
# 安裝依賴
npm install

# 開發模式
npm run dev

# 建置
npm run build

# Replit 會自動偵測並運行
```

### 6.2 環境變數設定
```bash
# .env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_anon_key
VITE_MQTT_BROKER=wss://broker.hivemq.com:8884/mqtt
```

### 6.3 監控與日誌
```javascript
// 錯誤追蹤
window.addEventListener('error', (event) => {
  supabase.from('error_logs').insert({
    message: event.message,
    stack: event.error?.stack,
    url: window.location.href,
    timestamp: new Date().toISOString()
  })
})

// 效能監控
window.addEventListener('load', () => {
  const perfData = performance.getEntriesByType('navigation')[0]
  supabase.from('performance_logs').insert({
    load_time: perfData.loadEventEnd - perfData.fetchStart,
    dom_ready: perfData.domContentLoadedEventEnd - perfData.fetchStart,
    timestamp: new Date().toISOString()
  })
})
```

## 7. 測試策略

### 7.1 單元測試
```javascript
// 使用 Vitest
import { describe, it, expect } from 'vitest'
import { calculateDistance } from './utils'

describe('calculateDistance', () => {
  it('should calculate correct distance between two points', () => {
    const distance = calculateDistance(25.0330, 121.5654, 25.0340, 121.5664)
    expect(distance).toBeCloseTo(0.14, 2) // 約140公尺
  })
})
```

### 7.2 整合測試
```javascript
// 測試遊戲流程
describe('Game Flow', () => {
  it('should complete a game session', async () => {
    // 創建遊戲場次
    const session = await createGameSession(gameId)
    
    // 完成第一個頁面
    await completeTextVerify(session.id, 'correct_answer')
    
    // 檢查進度
    const progress = await getPlayerProgress(session.id)
    expect(progress.current_page_order).toBe(2)
  })
})
```

## 8. 擴展性規劃

### 8.1 微服務架構 (未來)
當系統規模擴大時,可考慮拆分為微服務:
- **遊戲引擎服務**: 處理遊戲邏輯
- **設備管理服務**: 管理 Arduino 設備
- **即時通訊服務**: 處理聊天與即時更新
- **分析服務**: 數據分析與報表

### 8.2 CDN 整合
```javascript
// 使用 Cloudflare CDN 加速靜態資源
const CDN_URL = 'https://cdn.jiachun.com'

function getCDNUrl(path) {
  return `${CDN_URL}${path}`
}
```

### 8.3 負載平衡
- 使用 Vercel 的 Edge Network 自動負載平衡
- Supabase 自動擴展資料庫連線池
- MQTT Broker 可升級至 HiveMQ Professional

## 總結

本技術規格書提供了完整的實作細節,涵蓋前端、後端、IoT 整合、安全性、效能優化等各個面向。開發團隊可以直接依據本文件進行開發,確保系統的穩定性與可擴展性。
