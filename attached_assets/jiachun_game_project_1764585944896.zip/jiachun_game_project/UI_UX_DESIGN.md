# UI/UX 視覺設計規格書

## 1. 設計理念

### 1.1 核心概念

**賈村競技場實境遊戲系統**的視覺設計以**軍事戰術風格**為主軸,融合現代科技感與實境體驗的沉浸感,打造出專業、刺激、易用的遊戲介面。

設計三大原則:

1. **直覺操作**: 玩家在戶外環境中使用手機,介面必須一目了然,減少認知負擔
2. **視覺衝擊**: 運用軍事風格的配色與圖示,營造緊張刺激的氛圍
3. **資訊清晰**: 在複雜的遊戲邏輯中,確保關鍵資訊突出顯示

### 1.2 設計風格關鍵字

- **軍事戰術** (Military Tactical)
- **科技未來** (Tech Futuristic)
- **沉浸體驗** (Immersive Experience)
- **動態互動** (Dynamic Interaction)

## 2. 色彩系統

### 2.1 主色調

```css
:root {
  /* 主要色彩 */
  --primary: #d97706;        /* 軍事橘 - 用於主要按鈕、強調元素 */
  --primary-dark: #b45309;   /* 深橘 - 按鈕按下狀態 */
  --primary-light: #fbbf24;  /* 亮橘 - 懸停狀態 */
  
  /* 次要色彩 */
  --secondary: #059669;      /* 戰術綠 - 成功狀態、完成標記 */
  --secondary-dark: #047857; /* 深綠 */
  --secondary-light: #10b981;/* 亮綠 */
  
  /* 強調色彩 */
  --accent: #dc2626;         /* 警示紅 - 危險、錯誤、緊急 */
  --accent-dark: #b91c1c;    /* 深紅 */
  --accent-light: #ef4444;   /* 亮紅 */
  
  /* 中性色彩 */
  --neutral-900: #111827;    /* 最深灰 - 主背景 */
  --neutral-800: #1f2937;    /* 深灰 - 卡片背景 */
  --neutral-700: #374151;    /* 中深灰 - 次要背景 */
  --neutral-600: #4b5563;    /* 中灰 - 邊框 */
  --neutral-500: #6b7280;    /* 淺中灰 - 次要文字 */
  --neutral-400: #9ca3af;    /* 淺灰 - 提示文字 */
  --neutral-300: #d1d5db;    /* 很淺灰 - 分隔線 */
  --neutral-200: #e5e7eb;    /* 極淺灰 */
  --neutral-100: #f3f4f6;    /* 接近白 */
  
  /* 文字色彩 */
  --text-primary: #f9fafb;   /* 主要文字 - 幾乎白色 */
  --text-secondary: #d1d5db; /* 次要文字 - 淺灰 */
  --text-tertiary: #9ca3af;  /* 第三級文字 - 中淺灰 */
  
  /* 功能色彩 */
  --success: #10b981;        /* 成功 */
  --warning: #f59e0b;        /* 警告 */
  --error: #ef4444;          /* 錯誤 */
  --info: #3b82f6;           /* 資訊 */
}
```

### 2.2 色彩應用場景

| 色彩 | 應用場景 | 範例 |
| --- | --- | --- |
| **軍事橘** | 主要操作按鈕、進度條、選中狀態 | 「開始任務」按鈕、當前頁面指示器 |
| **戰術綠** | 成功訊息、完成標記、正確答案 | 「任務完成」提示、答對時的勾選圖示 |
| **警示紅** | 錯誤訊息、危險警告、倒數計時 | 「答案錯誤」提示、「時間不足」警告 |
| **深灰系** | 背景、卡片、輸入框 | 頁面背景、對話框背景 |
| **淺灰系** | 文字、圖示、分隔線 | 說明文字、圖示顏色 |

## 3. 字體系統

### 3.1 字體選擇

```css
:root {
  /* 中文字體 */
  --font-chinese: 'Noto Sans TC', 'Microsoft JhengHei', sans-serif;
  
  /* 英文字體 */
  --font-english: 'Rajdhani', 'Roboto', sans-serif;
  
  /* 數字字體 (用於分數、倒數計時) */
  --font-number: 'Orbitron', 'Courier New', monospace;
  
  /* 字體大小 */
  --text-xs: 0.75rem;    /* 12px - 提示文字 */
  --text-sm: 0.875rem;   /* 14px - 次要文字 */
  --text-base: 1rem;     /* 16px - 主要文字 */
  --text-lg: 1.125rem;   /* 18px - 小標題 */
  --text-xl: 1.25rem;    /* 20px - 標題 */
  --text-2xl: 1.5rem;    /* 24px - 大標題 */
  --text-3xl: 1.875rem;  /* 30px - 特大標題 */
  --text-4xl: 2.25rem;   /* 36px - 超大標題 */
  
  /* 字重 */
  --font-normal: 400;
  --font-medium: 500;
  --font-semibold: 600;
  --font-bold: 700;
  --font-black: 900;
}
```

### 3.2 字體應用規則

| 元素 | 字體 | 大小 | 字重 | 用途 |
| --- | --- | --- | --- | --- |
| **頁面標題** | Rajdhani | 2xl-3xl | Bold | 遊戲名稱、關卡標題 |
| **內容標題** | Noto Sans TC | xl-2xl | Semibold | 對話角色名、任務名稱 |
| **主要內容** | Noto Sans TC | base-lg | Normal | 故事文字、對話內容 |
| **次要內容** | Noto Sans TC | sm | Normal | 提示文字、說明 |
| **分數/計時** | Orbitron | 2xl-4xl | Bold | 積分顯示、倒數計時 |
| **按鈕文字** | Rajdhani | base-lg | Semibold | 所有按鈕 |

## 4. 組件設計

### 4.1 按鈕 (Button)

#### 主要按鈕 (Primary Button)
```css
.btn-primary {
  background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
  color: var(--text-primary);
  padding: 12px 32px;
  border-radius: 8px;
  font-family: var(--font-english);
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  text-transform: uppercase;
  letter-spacing: 1px;
  box-shadow: 0 4px 12px rgba(217, 119, 6, 0.3);
  transition: all 0.3s ease;
  border: 2px solid transparent;
}

.btn-primary:hover {
  background: linear-gradient(135deg, var(--primary-light) 0%, var(--primary) 100%);
  box-shadow: 0 6px 20px rgba(217, 119, 6, 0.5);
  transform: translateY(-2px);
}

.btn-primary:active {
  transform: translateY(0);
  box-shadow: 0 2px 8px rgba(217, 119, 6, 0.3);
}
```

#### 次要按鈕 (Secondary Button)
```css
.btn-secondary {
  background: transparent;
  color: var(--primary);
  padding: 12px 32px;
  border-radius: 8px;
  border: 2px solid var(--primary);
  font-family: var(--font-english);
  font-size: var(--text-lg);
  font-weight: var(--font-semibold);
  transition: all 0.3s ease;
}

.btn-secondary:hover {
  background: var(--primary);
  color: var(--neutral-900);
}
```

#### 危險按鈕 (Danger Button)
```css
.btn-danger {
  background: linear-gradient(135deg, var(--accent) 0%, var(--accent-dark) 100%);
  color: var(--text-primary);
  /* 其他樣式同主要按鈕 */
}
```

### 4.2 卡片 (Card)

```css
.card {
  background: var(--neutral-800);
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
  border: 1px solid var(--neutral-700);
  transition: all 0.3s ease;
}

.card:hover {
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4);
  transform: translateY(-4px);
}

.card-header {
  border-bottom: 2px solid var(--primary);
  padding-bottom: 12px;
  margin-bottom: 16px;
}

.card-title {
  font-family: var(--font-english);
  font-size: var(--text-xl);
  font-weight: var(--font-bold);
  color: var(--text-primary);
  text-transform: uppercase;
}
```

### 4.3 輸入框 (Input)

```css
.input {
  background: var(--neutral-900);
  border: 2px solid var(--neutral-600);
  border-radius: 8px;
  padding: 12px 16px;
  color: var(--text-primary);
  font-size: var(--text-base);
  transition: all 0.3s ease;
}

.input:focus {
  outline: none;
  border-color: var(--primary);
  box-shadow: 0 0 0 3px rgba(217, 119, 6, 0.2);
}

.input::placeholder {
  color: var(--text-tertiary);
}

/* 錯誤狀態 */
.input.error {
  border-color: var(--accent);
}

/* 成功狀態 */
.input.success {
  border-color: var(--secondary);
}
```

### 4.4 進度條 (Progress Bar)

```css
.progress-bar {
  width: 100%;
  height: 8px;
  background: var(--neutral-700);
  border-radius: 4px;
  overflow: hidden;
  position: relative;
}

.progress-bar-fill {
  height: 100%;
  background: linear-gradient(90deg, var(--primary) 0%, var(--primary-light) 100%);
  border-radius: 4px;
  transition: width 0.5s ease;
  position: relative;
  overflow: hidden;
}

/* 動畫效果 */
.progress-bar-fill::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.3) 50%,
    transparent 100%
  );
  animation: shimmer 2s infinite;
}

@keyframes shimmer {
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
}
```

### 4.5 徽章 (Badge)

```css
.badge {
  display: inline-flex;
  align-items: center;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: var(--text-sm);
  font-weight: var(--font-semibold);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.badge-success {
  background: rgba(16, 185, 129, 0.2);
  color: var(--success);
  border: 1px solid var(--success);
}

.badge-warning {
  background: rgba(245, 158, 11, 0.2);
  color: var(--warning);
  border: 1px solid var(--warning);
}

.badge-error {
  background: rgba(239, 68, 68, 0.2);
  color: var(--error);
  border: 1px solid var(--error);
}
```

## 5. 頁面佈局

### 5.1 玩家端 - 遊戲頁面

```
┌─────────────────────────────────────────┐
│  ┌─────────────────────────────────┐   │ ← Header (固定)
│  │  [≡]  任務: 戰術突襲    [分數]  │   │   - 選單按鈕
│  │         150 pts                  │   │   - 任務名稱
│  └─────────────────────────────────┘   │   - 當前分數
│                                         │
│  ┌─────────────────────────────────┐   │ ← Progress (進度條)
│  │  ████████░░░░░░░░░░░░  60%      │   │
│  └─────────────────────────────────┘   │
│                                         │
│  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓   │
│  ┃                                 ┃   │
│  ┃      [內容區域]                 ┃   │ ← Content (滾動)
│  ┃                                 ┃   │   - 字卡/對話/影片
│  ┃      根據頁面類型顯示不同內容    ┃   │   - 驗證/互動
│  ┃                                 ┃   │   - 地圖/拍照
│  ┃                                 ┃   │
│  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛   │
│                                         │
│  ┌─────────────────────────────────┐   │ ← Action (固定)
│  │  [  繼續  ]  [  提示  ]         │   │   - 主要操作按鈕
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

### 5.2 玩家端 - 地圖導航

```
┌─────────────────────────────────────────┐
│  ┌─────────────────────────────────┐   │
│  │  [←]  地圖導航         [聊天]   │   │ ← Header
│  └─────────────────────────────────┘   │
│                                         │
│  ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓   │
│  ┃         🗺️ 地圖區域            ┃   │
│  ┃                                 ┃   │
│  ┃    📍 你的位置                  ┃   │ ← Map (全螢幕)
│  ┃                                 ┃   │   - 玩家位置
│  ┃    🎯 任務點 A (150m)           ┃   │   - 任務點標記
│  ┃                                 ┃   │   - 距離顯示
│  ┃    🎯 任務點 B (320m)           ┃   │
│  ┃                                 ┃   │
│  ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛   │
│                                         │
│  ┌─────────────────────────────────┐   │
│  │  [📍 重新定位]  [🧭 指南針]    │   │ ← Tools
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

### 5.3 管理端 - 遊戲編輯器

```
┌─────────────────────────────────────────────────────────┐
│  ┌─────────────────────────────────────────────────┐   │
│  │  [☰] 賈村遊戲管理系統    [預覽] [儲存] [發布]  │   │ ← Top Bar
│  └─────────────────────────────────────────────────┘   │
│                                                         │
│  ┌──────┬──────────────────────┬──────────────────┐   │
│  │      │  頁面列表            │  頁面設定        │   │
│  │ 選單 │                      │                  │   │
│  │      │  1. 開場白 (字卡)    │  ┌────────────┐ │   │
│  │ 遊戲 │  2. 指揮官對話       │  │ 頁面類型:  │ │   │
│  │ 道具 │  3. 任務說明         │  │ [字卡 ▼]   │ │   │
│  │ 事件 │  4. 射擊任務 ⭐      │  └────────────┘ │   │
│  │ 設備 │  5. 文字驗證         │                  │   │
│  │ 數據 │  [+ 新增頁面]        │  標題:           │   │
│  │      │                      │  [___________]   │   │
│  │      │  可拖曳排序          │                  │   │
│  │      │                      │  內容:           │   │
│  │      │                      │  [___________]   │   │
│  └──────┴──────────────────────┴──────────────────┘   │
└─────────────────────────────────────────────────────────┘
```

## 6. 頁面模組視覺設計

### 6.1 字卡頁面

```css
.text-card-page {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 60vh;
  padding: 32px;
  background: linear-gradient(135deg, var(--neutral-900) 0%, var(--neutral-800) 100%);
  border-radius: 16px;
  position: relative;
  overflow: hidden;
}

/* 背景裝飾 */
.text-card-page::before {
  content: '';
  position: absolute;
  top: -50%;
  right: -50%;
  width: 200%;
  height: 200%;
  background: radial-gradient(circle, rgba(217, 119, 6, 0.1) 0%, transparent 70%);
  animation: pulse 4s ease-in-out infinite;
}

.text-card-title {
  font-family: var(--font-english);
  font-size: var(--text-3xl);
  font-weight: var(--font-black);
  color: var(--primary);
  text-transform: uppercase;
  margin-bottom: 24px;
  text-align: center;
  letter-spacing: 2px;
  text-shadow: 0 0 20px rgba(217, 119, 6, 0.5);
}

.text-card-content {
  font-family: var(--font-chinese);
  font-size: var(--text-lg);
  line-height: 1.8;
  color: var(--text-secondary);
  text-align: center;
  max-width: 600px;
}
```

### 6.2 對話頁面

```css
.dialogue-page {
  padding: 24px;
}

.dialogue-message {
  display: flex;
  gap: 16px;
  margin-bottom: 24px;
  animation: slideIn 0.5s ease-out;
}

.dialogue-avatar {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  border: 3px solid var(--primary);
  box-shadow: 0 0 20px rgba(217, 119, 6, 0.3);
}

.dialogue-bubble {
  flex: 1;
  background: var(--neutral-800);
  border-radius: 16px;
  padding: 16px 20px;
  position: relative;
  border: 1px solid var(--neutral-700);
}

/* 對話框箭頭 */
.dialogue-bubble::before {
  content: '';
  position: absolute;
  left: -10px;
  top: 20px;
  width: 0;
  height: 0;
  border-top: 10px solid transparent;
  border-bottom: 10px solid transparent;
  border-right: 10px solid var(--neutral-800);
}

.dialogue-name {
  font-family: var(--font-english);
  font-size: var(--text-sm);
  font-weight: var(--font-bold);
  color: var(--primary);
  text-transform: uppercase;
  margin-bottom: 8px;
}

.dialogue-text {
  font-family: var(--font-chinese);
  font-size: var(--text-base);
  line-height: 1.6;
  color: var(--text-primary);
}

@keyframes slideIn {
  from {
    opacity: 0;
    transform: translateX(-20px);
  }
  to {
    opacity: 1;
    transform: translateX(0);
  }
}
```

### 6.3 射擊任務頁面

```css
.shooting-mission-page {
  padding: 24px;
  text-align: center;
}

.mission-status {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 16px;
  margin-bottom: 32px;
}

.status-card {
  background: var(--neutral-800);
  border-radius: 12px;
  padding: 20px;
  border: 2px solid var(--neutral-700);
}

.status-label {
  font-size: var(--text-sm);
  color: var(--text-tertiary);
  text-transform: uppercase;
  margin-bottom: 8px;
}

.status-value {
  font-family: var(--font-number);
  font-size: var(--text-3xl);
  font-weight: var(--font-black);
  color: var(--primary);
}

.target-display {
  width: 300px;
  height: 300px;
  margin: 0 auto 32px;
  position: relative;
  background: radial-gradient(circle, var(--accent) 0%, var(--accent-dark) 30%, var(--neutral-800) 100%);
  border-radius: 50%;
  border: 4px solid var(--primary);
  box-shadow: 0 0 40px rgba(217, 119, 6, 0.5);
  animation: targetPulse 2s ease-in-out infinite;
}

@keyframes targetPulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}

.hit-indicator {
  position: absolute;
  width: 20px;
  height: 20px;
  background: var(--warning);
  border-radius: 50%;
  animation: hitFlash 0.5s ease-out;
}

@keyframes hitFlash {
  0% {
    transform: scale(0);
    opacity: 1;
  }
  100% {
    transform: scale(2);
    opacity: 0;
  }
}
```

### 6.4 拍照任務頁面

```css
.photo-mission-page {
  padding: 24px;
}

.photo-instruction {
  background: var(--neutral-800);
  border-left: 4px solid var(--primary);
  padding: 20px;
  margin-bottom: 24px;
  border-radius: 8px;
}

.camera-preview {
  width: 100%;
  aspect-ratio: 4/3;
  background: var(--neutral-900);
  border-radius: 12px;
  overflow: hidden;
  position: relative;
  margin-bottom: 24px;
}

.camera-overlay {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  background: rgba(0, 0, 0, 0.3);
}

.camera-frame {
  width: 80%;
  height: 80%;
  border: 3px dashed var(--primary);
  border-radius: 12px;
  animation: framePulse 2s ease-in-out infinite;
}

@keyframes framePulse {
  0%, 100% { opacity: 0.5; }
  50% { opacity: 1; }
}

.capture-button {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  background: var(--primary);
  border: 6px solid var(--neutral-800);
  box-shadow: 0 0 30px rgba(217, 119, 6, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto;
  cursor: pointer;
  transition: all 0.3s ease;
}

.capture-button:active {
  transform: scale(0.9);
}
```

## 7. 動畫效果

### 7.1 頁面轉場

```css
/* 淡入效果 */
@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

/* 滑入效果 */
@keyframes slideInUp {
  from {
    opacity: 0;
    transform: translateY(30px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 縮放效果 */
@keyframes scaleIn {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

.page-transition {
  animation: fadeIn 0.5s ease-out;
}
```

### 7.2 互動回饋

```css
/* 按鈕點擊波紋效果 */
.ripple {
  position: relative;
  overflow: hidden;
}

.ripple::after {
  content: '';
  position: absolute;
  top: 50%;
  left: 50%;
  width: 0;
  height: 0;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.5);
  transform: translate(-50%, -50%);
  transition: width 0.6s, height 0.6s;
}

.ripple:active::after {
  width: 300px;
  height: 300px;
}
```

### 7.3 載入動畫

```css
.loading-spinner {
  width: 50px;
  height: 50px;
  border: 4px solid var(--neutral-700);
  border-top-color: var(--primary);
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  to { transform: rotate(360deg); }
}

/* 脈衝載入 */
.pulse-loader {
  display: flex;
  gap: 8px;
}

.pulse-dot {
  width: 12px;
  height: 12px;
  background: var(--primary);
  border-radius: 50%;
  animation: pulse 1.4s ease-in-out infinite;
}

.pulse-dot:nth-child(2) {
  animation-delay: 0.2s;
}

.pulse-dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes pulse {
  0%, 80%, 100% {
    opacity: 0.3;
    transform: scale(0.8);
  }
  40% {
    opacity: 1;
    transform: scale(1);
  }
}
```

## 8. 響應式設計

### 8.1 斷點定義

```css
/* 手機 (預設) */
@media (min-width: 640px) {
  /* 大手機 / 小平板 */
}

@media (min-width: 768px) {
  /* 平板 */
  .container {
    max-width: 720px;
  }
}

@media (min-width: 1024px) {
  /* 桌面 */
  .container {
    max-width: 960px;
  }
}

@media (min-width: 1280px) {
  /* 大桌面 */
  .container {
    max-width: 1200px;
  }
}
```

### 8.2 觸控優化

```css
/* 增大觸控目標 */
.touch-target {
  min-width: 44px;
  min-height: 44px;
  padding: 12px;
}

/* 防止雙擊縮放 */
.no-zoom {
  touch-action: manipulation;
}

/* 滑動優化 */
.smooth-scroll {
  -webkit-overflow-scrolling: touch;
  scroll-behavior: smooth;
}
```

## 9. 圖示系統

### 9.1 圖示庫選擇

使用 **Heroicons** 作為主要圖示庫,輔以自訂的軍事風格圖示。

### 9.2 常用圖示

| 功能 | 圖示 | 說明 |
| --- | --- | --- |
| 選單 | ☰ | 漢堡選單 |
| 返回 | ← | 返回上一頁 |
| 地圖 | 🗺️ | 地圖導航 |
| 拍照 | 📷 | 拍照功能 |
| 聊天 | 💬 | 即時聊天 |
| 設定 | ⚙️ | 設定選項 |
| 提示 | 💡 | 提示功能 |
| 射擊 | 🎯 | 射擊任務 |
| 位置 | 📍 | GPS定位 |
| 分數 | ⭐ | 積分顯示 |

## 10. 無障礙設計

### 10.1 色彩對比

確保所有文字與背景的對比度符合 WCAG AA 標準 (至少 4.5:1)。

### 10.2 語意化 HTML

```html
<header role="banner">
  <nav role="navigation" aria-label="主選單">
    <!-- 導航內容 -->
  </nav>
</header>

<main role="main">
  <article aria-labelledby="page-title">
    <h1 id="page-title">任務標題</h1>
    <!-- 頁面內容 -->
  </article>
</main>

<button aria-label="開始任務" aria-describedby="mission-desc">
  開始
</button>
<p id="mission-desc" class="sr-only">
  點擊此按鈕開始戰術突襲任務
</p>
```

### 10.3 鍵盤導航

確保所有互動元素都可透過鍵盤操作 (Tab, Enter, Space)。

## 11. 設計資產

### 11.1 圖片規格

| 用途 | 尺寸 | 格式 | 說明 |
| --- | --- | --- | --- |
| 遊戲封面 | 1200x630 | WebP/JPG | 16:9 比例 |
| 角色頭像 | 200x200 | WebP/PNG | 正方形,透明背景 |
| 道具圖示 | 128x128 | WebP/PNG | 正方形,透明背景 |
| 背景圖片 | 1920x1080 | WebP/JPG | Full HD |
| QR Code | 512x512 | PNG | 高解析度 |

### 11.2 圖片優化

- 使用 WebP 格式減少檔案大小
- 實作 lazy loading
- 提供多種尺寸的響應式圖片

```html
<picture>
  <source srcset="image-small.webp" media="(max-width: 640px)" type="image/webp">
  <source srcset="image-medium.webp" media="(max-width: 1024px)" type="image/webp">
  <source srcset="image-large.webp" type="image/webp">
  <img src="image-fallback.jpg" alt="描述" loading="lazy">
</picture>
```

## 12. 設計檢查清單

### 12.1 視覺一致性
- [ ] 色彩使用符合設計系統
- [ ] 字體大小與字重一致
- [ ] 間距使用 8px 網格系統
- [ ] 圓角統一使用 8px/12px/16px

### 12.2 互動體驗
- [ ] 所有按鈕都有 hover/active 狀態
- [ ] 載入狀態有明確指示
- [ ] 錯誤訊息清晰易懂
- [ ] 成功操作有正向回饋

### 12.3 效能
- [ ] 圖片已優化
- [ ] 動畫流暢 (60fps)
- [ ] 首屏載入時間 < 3秒
- [ ] 互動回應時間 < 100ms

### 12.4 可用性
- [ ] 觸控目標 ≥ 44x44px
- [ ] 文字可讀性良好
- [ ] 色彩對比度符合標準
- [ ] 支援鍵盤導航

## 總結

本 UI/UX 設計規格書為賈村競技場實境遊戲系統提供了完整的視覺設計指南。透過軍事戰術風格的色彩與字體,結合現代化的組件設計與流暢的動畫效果,打造出專業、刺激、易用的遊戲體驗。

設計團隊可依據本規格書進行視覺設計與前端開發,確保整體風格的一致性與使用者體驗的優質性。
