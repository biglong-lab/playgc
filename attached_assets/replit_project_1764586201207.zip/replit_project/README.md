# 賈村競技體驗場 - 實境遊戲系統 (Replit 專案)

這是一個完整的 React + Vite 專案,專為賈村競技體驗場設計的實境遊戲系統。

## 🚀 快速開始

### 1. 在 Replit 中建立專案

1. 前往 [Replit](https://replit.com)
2. 點擊 "Create Repl"
3. 選擇 "Import from GitHub" 或 "Blank Repl"
4. 如果選擇 Blank Repl,請選擇 "Node.js" 模板
5. 將此專案的所有檔案上傳到 Replit

### 2. 設定環境變數

在 Replit 左側工具欄中選擇 "Secrets",新增以下環境變數:

```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_MQTT_BROKER=wss://broker.hivemq.com:8884/mqtt
```

### 3. 安裝依賴

在 Replit 的 Shell 中執行:

```bash
npm install
```

### 4. 啟動開發伺服器

```bash
npm run dev
```

Replit 會自動開啟預覽視窗。

## 📁 專案結構

```
src/
├── components/          # React 組件
│   ├── common/         # 通用組件 (Button, Card, Input, etc.)
│   ├── game/           # 遊戲相關組件
│   └── admin/          # 後台管理組件
├── pages/              # 頁面組件
│   ├── Player/         # 玩家端頁面
│   │   ├── PlayerLayout.jsx
│   │   ├── GameLobby.jsx
│   │   ├── GamePlay.jsx
│   │   ├── MapView.jsx
│   │   └── Leaderboard.jsx
│   ├── Admin/          # 管理端頁面
│   │   ├── AdminLayout.jsx
│   │   ├── Dashboard.jsx
│   │   ├── GameEditor.jsx
│   │   └── DeviceManagement.jsx
│   └── Auth/           # 認證頁面
│       ├── Login.jsx
│       └── Register.jsx
├── services/           # 服務層
│   ├── supabase.js     # Supabase 客戶端與 API
│   └── mqtt.js         # MQTT 客戶端與設備控制
├── stores/             # 狀態管理 (Zustand)
│   ├── authStore.js    # 認證狀態
│   └── gameStore.js    # 遊戲狀態
├── utils/              # 工具函數
│   └── helpers.js      # 通用輔助函數
├── styles/             # 樣式檔案
│   └── index.css       # 全域樣式與 Tailwind
├── App.jsx             # 主應用組件與路由
└── main.jsx            # 應用程式進入點
```

## 🎨 技術堆疊

- **前端框架**: React 18 + Vite 5
- **UI 框架**: Tailwind CSS + DaisyUI
- **狀態管理**: Zustand
- **資料獲取**: React Query
- **路由**: React Router v6
- **後端服務**: Supabase (BaaS)
- **IoT 通訊**: MQTT.js
- **地圖**: Leaflet.js

## 🔧 後端設定

### Supabase 設定

1. 前往 [Supabase](https://supabase.com/) 註冊並創建專案
2. 在 SQL Editor 中執行 `DATABASE_SCHEMA.sql` (位於專案根目錄)
3. 在 Storage 中創建兩個 Bucket:
   - `game-assets` (Public)
   - `game-uploads` (Private)
4. 複製 Project URL 和 anon key 到 Replit Secrets

### MQTT 設定

預設使用 HiveMQ Cloud 的公開 Broker,無需額外設定。

## 📱 功能模組

### 玩家端
- ✅ 遊戲大廳 (選擇遊戲)
- ✅ 遊戲進行 (頁面模組渲染)
- ✅ 地圖導航 (GPS 定位)
- ✅ 排行榜
- 🚧 即時聊天 (待實作)
- 🚧 拍照上傳 (待實作)

### 管理端
- ✅ 儀表板 (數據概覽)
- ✅ 遊戲編輯器 (基礎架構)
- ✅ 設備管理 (Arduino 控制)
- 🚧 數據分析 (待實作)

### 認證系統
- ✅ 登入
- ✅ 註冊
- 🚧  密碼重設 (待實作)

## 🎮 頁面模組系統

目前專案已建立基礎架構,支援以下頁面模組:

- 字卡 (text_card)
- 對話 (dialogue)
- 影片 (video)
- 圖文按鈕 (button)
- 文字驗證 (text_verify)
- 選擇驗證 (choice_verify)

每個模組的具體實作需要在 `src/components/game/` 中建立對應的組件。

## 🔌 Arduino 整合

MQTT 服務已建立,可透過以下方式控制設備:

```javascript
import { deviceService } from './services/mqtt'

// 啟動設備
await deviceService.activateDevice('target_001')

// 訂閱設備數據
const unsubscribe = deviceService.subscribeToDeviceData('target_001', (data) => {
  console.log('Device data:', data)
})
```

Arduino 端程式碼請參考 `TECHNICAL_SPEC.md`。

## 📚 相關文件

- `GAME_ARCHITECTURE.md` - 遊戲架構設計
- `TECHNICAL_SPEC.md` - 技術實作規格
- `UI_UX_DESIGN.md` - 視覺設計規格
- `DATABASE_SCHEMA.sql` - 資料庫結構

## 🐛 已知問題

- 地圖組件尚未整合 Leaflet
- 頁面模組組件需要逐一實作
- 即時聊天功能待完成
- 圖片上傳與壓縮功能待整合

## 📝 開發建議

1. 先完成 Supabase 後端設定
2. 測試認證系統 (登入/註冊)
3. 實作各個頁面模組組件
4. 整合 Leaflet 地圖
5. 實作 Arduino 設備控制
6. 測試完整遊戲流程

## 🤝 貢獻

本專案由 Manus AI 規劃設計,歡迎提出改進建議。

## 📄 授權

本專案專為賈村競技體驗場開發,版權所有。
