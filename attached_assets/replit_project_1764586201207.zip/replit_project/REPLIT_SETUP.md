# Replit 專案快速設定指南

## 📦 方式一:直接在 Replit 匯入

### 步驟 1: 建立新的 Repl

1. 前往 [Replit](https://replit.com)
2. 點擊 "+ Create Repl"
3. 選擇 "Import from GitHub" 或 "Node.js" 模板
4. 為專案命名,例如 "jiachun-game-system"

### 步驟 2: 上傳專案檔案

如果選擇 Node.js 模板:

1. 下載 `replit_project.zip` 並解壓縮
2. 在 Replit 左側檔案瀏覽器中,刪除預設的檔案
3. 將解壓縮後的所有檔案拖曳上傳到 Replit

### 步驟 3: 設定環境變數

1. 點擊左側工具欄的 🔒 "Secrets" 圖示
2. 新增以下環境變數:

| Key | Value | 說明 |
| --- | --- | --- |
| `VITE_SUPABASE_URL` | `https://xxxxx.supabase.co` | 您的 Supabase 專案 URL |
| `VITE_SUPABASE_ANON_KEY` | `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` | Supabase anon public 金鑰 |
| `VITE_MQTT_BROKER` | `wss://broker.hivemq.com:8884/mqtt` | MQTT Broker 位址 (預設值) |

### 步驟 4: 安裝依賴

在 Replit 的 Shell 中執行:

```bash
npm install
```

等待所有套件安裝完成 (約 1-2 分鐘)。

### 步驟 5: 啟動開發伺服器

```bash
npm run dev
```

Replit 會自動偵測並開啟預覽視窗。

## 🔧 Supabase 後端設定

### 步驟 1: 建立 Supabase 專案

1. 前往 [Supabase](https://supabase.com/)
2. 點擊 "New Project"
3. 輸入專案名稱與密碼
4. 選擇地區 (建議選擇 Singapore 或 Tokyo)
5. 等待專案建立完成 (約 2 分鐘)

### 步驟 2: 建立資料庫結構

1. 在 Supabase 儀表板左側選擇 "SQL Editor"
2. 點擊 "New Query"
3. 複製 `DATABASE_SCHEMA.sql` 的內容並貼上
4. 點擊 "Run" 執行 SQL 指令
5. 確認所有資料表都已成功建立

### 步驟 3: 設定 Storage

1. 在左側選擇 "Storage"
2. 點擊 "New Bucket"
3. 建立兩個 Bucket:
   - **game-assets** (Public) - 用於遊戲封面、道具圖示等公開資源
   - **game-uploads** (Private) - 用於玩家上傳的照片等私密檔案
4. 為 `game-uploads` 設定存取策略 (參考 `DATABASE_SCHEMA.sql` 中的 Storage Policies)

### 步驟 4: 取得 API 金鑰

1. 在左側選擇 "Settings" > "API"
2. 複製以下資訊:
   - **Project URL** → 貼到 Replit Secrets 的 `VITE_SUPABASE_URL`
   - **anon public** → 貼到 Replit Secrets 的 `VITE_SUPABASE_ANON_KEY`

## 🎮 測試專案

### 測試認證系統

1. 在瀏覽器中開啟 Replit 預覽視窗
2. 點擊 "註冊"
3. 輸入測試帳號資訊並註冊
4. 確認可以成功登入

### 測試遊戲大廳

1. 登入後應該會看到遊戲大廳
2. 目前資料庫中沒有遊戲,會顯示 "目前沒有可用的遊戲"
3. 可以透過管理端新增測試遊戲

### 測試管理端

1. 在網址列中輸入 `/admin`
2. 應該會看到管理端儀表板
3. 測試遊戲編輯器與設備管理功能

## 📝 下一步開發

### 優先順序 1: 完成頁面模組組件

在 `src/components/game/` 中建立各個頁面模組組件:

- `TextCard.jsx` - 字卡頁面
- `Dialogue.jsx` - 對話頁面
- `VideoPlayer.jsx` - 影片頁面
- `ButtonGrid.jsx` - 圖文按鈕頁面
- `TextVerify.jsx` - 文字驗證頁面
- `ChoiceVerify.jsx` - 選擇驗證頁面

### 優先順序 2: 整合 Leaflet 地圖

在 `src/components/game/` 中建立:

- `MapComponent.jsx` - 地圖組件
- 整合到 `MapView.jsx` 頁面

### 優先順序 3: 實作即時聊天

在 `src/components/game/` 中建立:

- `ChatBox.jsx` - 聊天組件
- 使用 Supabase Realtime 訂閱訊息

### 優先順序 4: Arduino 設備整合

1. 準備 ESP32 開發板
2. 燒錄 `TECHNICAL_SPEC.md` 中的 Arduino 程式碼
3. 測試 MQTT 通訊
4. 在管理端監控設備狀態

## 🐛 常見問題

### Q: Replit 顯示 "Module not found" 錯誤

**A:** 確認已執行 `npm install` 安裝所有依賴套件。

### Q: 無法連接 Supabase

**A:** 檢查 Secrets 中的環境變數是否正確設定,並確認 Supabase 專案已啟動。

### Q: 地圖無法顯示

**A:** 目前地圖組件尚未完全整合 Leaflet,需要建立 `MapComponent.jsx` 組件。

### Q: MQTT 連線失敗

**A:** 確認使用的是 WebSocket 協定 (`wss://`),而非 TCP 協定 (`mqtt://`)。

### Q: Replit 預覽視窗一片空白

**A:** 
1. 檢查 Shell 中是否有錯誤訊息
2. 確認 `npm run dev` 已成功啟動
3. 嘗試重新整理預覽視窗

## 📚 參考資源

- [Replit 官方文件](https://docs.replit.com/)
- [Supabase 官方文件](https://supabase.com/docs)
- [React Router 文件](https://reactrouter.com/)
- [Tailwind CSS 文件](https://tailwindcss.com/docs)
- [DaisyUI 組件庫](https://daisyui.com/components/)

## 🎯 專案完成檢查清單

- [ ] Supabase 專案已建立並設定完成
- [ ] 資料庫結構已建立
- [ ] Storage Buckets 已設定
- [ ] 環境變數已正確設定
- [ ] 專案可以成功啟動
- [ ] 認證系統可以正常運作
- [ ] 遊戲大廳可以顯示
- [ ] 管理端可以存取
- [ ] 頁面模組組件已實作
- [ ] 地圖功能已整合
- [ ] 即時聊天已實作
- [ ] Arduino 設備已連接測試

## 💡 提示

- 開發時建議使用 Chrome DevTools 查看 Console 錯誤訊息
- Supabase 提供免費的 50,000 月活躍用戶額度
- Replit 免費方案適合開發與測試,正式環境建議部署至 Vercel
- 定期備份專案,可使用 Replit 的 Git 整合功能

祝開發順利! 🚀
