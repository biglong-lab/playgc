import React from 'react'

const Badge = ({ 
  children, 
  variant = 'primary',
  size = 'md',
  className = '' 
}) => {
  const variantClasses = {
    primary: 'bg-primary/20 text-primary border-primary',
    secondary: 'bg-secondary/20 text-secondary border-secondary',
    success: 'bg-success/20 text-success border-success',
    warning: 'bg-warning/20 text-warning border-warning',
    error: 'bg-error/20 text-error border-error',
    info: 'bg-info/20 text-info border-info',
  }

  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-1.5 text-base',
  }

  return (
    <span 
      className={`badge-custom border ${variantClasses[variant]} ${sizeClasses[size]} ${className}`}
    >
      {children}
    </span>
  )
}

export default Badge
