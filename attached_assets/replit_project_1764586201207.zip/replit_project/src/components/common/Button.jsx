import React from 'react'

const Button = ({ 
  children, 
  variant = 'primary', 
  size = 'md',
  fullWidth = false,
  disabled = false,
  loading = false,
  onClick,
  type = 'button',
  className = '',
  ...props 
}) => {
  const baseClasses = 'font-english font-semibold uppercase tracking-wider transition-all duration-300 rounded-lg'
  
  const variantClasses = {
    primary: 'bg-gradient-to-br from-primary to-primary-dark text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed',
    secondary: 'bg-transparent border-2 border-primary text-primary hover:bg-primary hover:text-base-100 disabled:opacity-50',
    danger: 'bg-gradient-to-br from-accent to-accent-dark text-white shadow-lg hover:shadow-xl hover:-translate-y-0.5 disabled:opacity-50',
    ghost: 'bg-transparent text-primary hover:bg-primary/10 disabled:opacity-50',
  }

  const sizeClasses = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-8 py-3 text-base',
    lg: 'px-10 py-4 text-lg',
  }

  const widthClass = fullWidth ? 'w-full' : ''

  return (
    <button
      type={type}
      disabled={disabled || loading}
      onClick={onClick}
      className={`${baseClasses} ${variantClasses[variant]} ${sizeClasses[size]} ${widthClass} ${className}`}
      {...props}
    >
      {loading ? (
        <span className="flex items-center justify-center gap-2">
          <span className="loading loading-spinner loading-sm"></span>
          載入中...
        </span>
      ) : (
        children
      )}
    </button>
  )
}

export default Button
