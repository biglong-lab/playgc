import React from 'react'

const Card = ({ 
  children, 
  title,
  subtitle,
  className = '',
  hoverable = true,
  ...props 
}) => {
  const hoverClass = hoverable ? 'hover:shadow-2xl hover:-translate-y-1' : ''

  return (
    <div 
      className={`bg-base-100 rounded-xl p-6 shadow-lg border border-neutral transition-all duration-300 ${hoverClass} ${className}`}
      {...props}
    >
      {(title || subtitle) && (
        <div className="border-b-2 border-primary pb-3 mb-4">
          {title && (
            <h3 className="font-english text-xl font-bold text-base-content uppercase">
              {title}
            </h3>
          )}
          {subtitle && (
            <p className="text-sm text-base-content/70 mt-1">
              {subtitle}
            </p>
          )}
        </div>
      )}
      {children}
    </div>
  )
}

export default Card
