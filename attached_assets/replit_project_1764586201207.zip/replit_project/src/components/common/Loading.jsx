import React from 'react'

const Loading = ({ 
  text = '載入中...', 
  fullScreen = false,
  size = 'md' 
}) => {
  const sizeClasses = {
    sm: 'loading-sm',
    md: 'loading-md',
    lg: 'loading-lg',
  }

  const content = (
    <div className="flex flex-col items-center justify-center gap-4">
      <span className={`loading loading-spinner text-primary ${sizeClasses[size]}`}></span>
      {text && (
        <p className="font-english text-base-content/70 uppercase tracking-wider">
          {text}
        </p>
      )}
    </div>
  )

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-base-200 flex items-center justify-center z-50">
        {content}
      </div>
    )
  }

  return (
    <div className="flex items-center justify-center p-8">
      {content}
    </div>
  )
}

export default Loading
