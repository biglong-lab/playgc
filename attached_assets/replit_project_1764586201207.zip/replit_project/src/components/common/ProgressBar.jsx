import React from 'react'

const ProgressBar = ({ 
  value = 0, 
  max = 100, 
  showLabel = true,
  className = '' 
}) => {
  const percentage = Math.min(Math.max((value / max) * 100, 0), 100)

  return (
    <div className={`w-full ${className}`}>
      <div className="progress-custom">
        <div 
          className="progress-fill relative overflow-hidden"
          style={{ width: `${percentage}%` }}
        >
          {/* 閃爍動畫效果 */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
        </div>
      </div>
      {showLabel && (
        <div className="flex justify-between items-center mt-2 text-sm">
          <span className="text-base-content/70">進度</span>
          <span className="font-number font-bold text-primary">{percentage.toFixed(0)}%</span>
        </div>
      )}
    </div>
  )
}

export default ProgressBar
