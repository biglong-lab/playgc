import { Outlet, Link, useLocation } from 'react-router-dom'

const AdminLayout = () => {
  const location = useLocation()

  const menuItems = [
    { path: '/admin', label: '儀表板', icon: '📊' },
    { path: '/admin/editor', label: '遊戲編輯器', icon: '🎮' },
    { path: '/admin/devices', label: '設備管理', icon: '🔧' },
  ]

  return (
    <div className="min-h-screen bg-base-200">
      {/* 頂部導航列 */}
      <header className="bg-base-100 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-black text-primary font-english uppercase">
              賈村管理系統
            </h1>
            <div className="flex gap-4">
              <button className="btn btn-ghost btn-sm">
                通知
              </button>
              <button className="btn btn-ghost btn-sm">
                設定
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* 側邊選單 */}
        <aside className="w-64 bg-base-100 min-h-[calc(100vh-80px)] p-4">
          <nav className="space-y-2">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                  location.pathname === item.path
                    ? 'bg-primary text-base-100 font-semibold'
                    : 'hover:bg-base-200'
                }`}
              >
                <span className="text-xl">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>
        </aside>

        {/* 主要內容區 */}
        <main className="flex-1 p-8">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default AdminLayout
