import Card from '../../components/common/Card'
import Badge from '../../components/common/Badge'

const Dashboard = () => {
  // 模擬數據
  const stats = [
    { label: '總遊戲數', value: 12, icon: '🎮', color: 'primary' },
    { label: '今日場次', value: 28, icon: '🎯', color: 'secondary' },
    { label: '活躍玩家', value: 156, icon: '👥', color: 'info' },
    { label: '設備在線', value: 8, icon: '🔧', color: 'success' },
  ]

  const recentSessions = [
    { id: 1, game: '戰術突襲', team: '神槍手隊', score: 850, status: 'completed' },
    { id: 2, game: '密室逃脫', team: '解謎達人', score: 720, status: 'playing' },
    { id: 3, game: '尋寶冒險', team: '探險家', score: 650, status: 'completed' },
  ]

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold mb-2">儀表板</h2>
        <p className="text-base-content/70">系統概覽與即時數據</p>
      </div>

      {/* 統計卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.label} hoverable={false}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-base-content/70 mb-1">{stat.label}</p>
                <p className="text-3xl font-number font-bold text-primary">
                  {stat.value}
                </p>
              </div>
              <div className="text-5xl opacity-50">{stat.icon}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* 近期場次 */}
      <Card title="近期遊戲場次">
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>遊戲</th>
                <th>隊伍</th>
                <th>分數</th>
                <th>狀態</th>
              </tr>
            </thead>
            <tbody>
              {recentSessions.map((session) => (
                <tr key={session.id}>
                  <td className="font-semibold">{session.game}</td>
                  <td>{session.team}</td>
                  <td className="font-number font-bold text-primary">
                    {session.score}
                  </td>
                  <td>
                    <Badge
                      variant={session.status === 'completed' ? 'success' : 'warning'}
                    >
                      {session.status === 'completed' ? '已完成' : '進行中'}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}

export default Dashboard
