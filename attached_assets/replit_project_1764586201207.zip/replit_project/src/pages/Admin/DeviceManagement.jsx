import { useState, useEffect } from 'react'
import Card from '../../components/common/Card'
import Badge from '../../components/common/Badge'
import Button from '../../components/common/Button'

const DeviceManagement = () => {
  // 模擬設備數據
  const [devices, setDevices] = useState([
    { id: 'target_001', name: '射擊靶機 A', type: 'shooting_target', status: 'online', lastHeartbeat: new Date() },
    { id: 'target_002', name: '射擊靶機 B', type: 'shooting_target', status: 'online', lastHeartbeat: new Date() },
    { id: 'sensor_001', name: '動作感應器 1', type: 'motion_sensor', status: 'offline', lastHeartbeat: new Date(Date.now() - 300000) },
    { id: 'light_001', name: 'LED 燈光控制', type: 'light_control', status: 'online', lastHeartbeat: new Date() },
  ])

  const getStatusBadge = (status) => {
    switch (status) {
      case 'online':
        return <Badge variant="success">在線</Badge>
      case 'offline':
        return <Badge variant="error">離線</Badge>
      case 'maintenance':
        return <Badge variant="warning">維護中</Badge>
      default:
        return <Badge>未知</Badge>
    }
  }

  const getDeviceTypeLabel = (type) => {
    const types = {
      shooting_target: '射擊靶機',
      motion_sensor: '動作感應器',
      light_control: '燈光控制',
      rfid_reader: 'RFID讀卡機'
    }
    return types[type] || type
  }

  const handleActivate = (deviceId) => {
    console.log('Activate device:', deviceId)
    // 這裡會呼叫 MQTT 服務
  }

  const handleDeactivate = (deviceId) => {
    console.log('Deactivate device:', deviceId)
    // 這裡會呼叫 MQTT 服務
  }

  const handleReset = (deviceId) => {
    console.log('Reset device:', deviceId)
    // 這裡會呼叫 MQTT 服務
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold mb-2">設備管理</h2>
          <p className="text-base-content/70">監控與控制 Arduino 設備</p>
        </div>
        <Button variant="primary">+ 新增設備</Button>
      </div>

      {/* 設備統計 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card hoverable={false}>
          <div className="text-center">
            <p className="text-sm text-base-content/70 mb-1">總設備數</p>
            <p className="text-3xl font-number font-bold text-primary">
              {devices.length}
            </p>
          </div>
        </Card>
        <Card hoverable={false}>
          <div className="text-center">
            <p className="text-sm text-base-content/70 mb-1">在線設備</p>
            <p className="text-3xl font-number font-bold text-success">
              {devices.filter(d => d.status === 'online').length}
            </p>
          </div>
        </Card>
        <Card hoverable={false}>
          <div className="text-center">
            <p className="text-sm text-base-content/70 mb-1">離線設備</p>
            <p className="text-3xl font-number font-bold text-error">
              {devices.filter(d => d.status === 'offline').length}
            </p>
          </div>
        </Card>
        <Card hoverable={false}>
          <div className="text-center">
            <p className="text-sm text-base-content/70 mb-1">維護中</p>
            <p className="text-3xl font-number font-bold text-warning">
              {devices.filter(d => d.status === 'maintenance').length}
            </p>
          </div>
        </Card>
      </div>

      {/* 設備列表 */}
      <Card title="設備列表">
        <div className="overflow-x-auto">
          <table className="table w-full">
            <thead>
              <tr>
                <th>設備 ID</th>
                <th>名稱</th>
                <th>類型</th>
                <th>狀態</th>
                <th>最後心跳</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {devices.map((device) => (
                <tr key={device.id}>
                  <td className="font-mono text-sm">{device.id}</td>
                  <td className="font-semibold">{device.name}</td>
                  <td>{getDeviceTypeLabel(device.type)}</td>
                  <td>{getStatusBadge(device.status)}</td>
                  <td className="text-sm text-base-content/70">
                    {device.lastHeartbeat.toLocaleTimeString('zh-TW')}
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleActivate(device.id)}
                        className="btn btn-success btn-xs"
                        disabled={device.status === 'online'}
                      >
                        啟動
                      </button>
                      <button
                        onClick={() => handleDeactivate(device.id)}
                        className="btn btn-error btn-xs"
                        disabled={device.status === 'offline'}
                      >
                        停用
                      </button>
                      <button
                        onClick={() => handleReset(device.id)}
                        className="btn btn-warning btn-xs"
                      >
                        重置
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}

export default DeviceManagement
