import { useState } from 'react'
import Card from '../../components/common/Card'
import Button from '../../components/common/Button'
import Input from '../../components/common/Input'

const GameEditor = () => {
  const [gameTitle, setGameTitle] = useState('')
  const [pages, setPages] = useState([])

  const pageTypes = [
    { value: 'text_card', label: '字卡', icon: '📝' },
    { value: 'dialogue', label: '對話', icon: '💬' },
    { value: 'video', label: '影片', icon: '🎥' },
    { value: 'button', label: '圖文按鈕', icon: '🔘' },
    { value: 'text_verify', label: '文字驗證', icon: '✍️' },
    { value: 'choice_verify', label: '選擇驗證', icon: '☑️' },
  ]

  const handleAddPage = (pageType) => {
    const newPage = {
      id: Date.now(),
      type: pageType,
      order: pages.length + 1,
      config: {}
    }
    setPages([...pages, newPage])
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold mb-2">遊戲編輯器</h2>
          <p className="text-base-content/70">創建與編輯實境遊戲</p>
        </div>
        <div className="flex gap-4">
          <Button variant="secondary">預覽</Button>
          <Button variant="primary">儲存</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 左側: 頁面列表 */}
        <div className="lg:col-span-1">
          <Card title="頁面列表">
            <div className="space-y-2 mb-4">
              {pages.map((page, index) => (
                <div
                  key={page.id}
                  className="p-3 bg-base-200 rounded-lg flex items-center justify-between cursor-pointer hover:bg-base-300 transition-colors"
                >
                  <span className="font-semibold">
                    {index + 1}. {pageTypes.find(t => t.value === page.type)?.label}
                  </span>
                  <button className="btn btn-ghost btn-xs">✕</button>
                </div>
              ))}
            </div>

            <div className="divider">新增頁面</div>

            <div className="grid grid-cols-2 gap-2">
              {pageTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => handleAddPage(type.value)}
                  className="btn btn-outline btn-sm"
                >
                  {type.icon} {type.label}
                </button>
              ))}
            </div>
          </Card>
        </div>

        {/* 右側: 頁面設定 */}
        <div className="lg:col-span-2">
          <Card title="遊戲設定">
            <div className="space-y-4">
              <Input
                label="遊戲標題"
                placeholder="輸入遊戲標題"
                value={gameTitle}
                onChange={(e) => setGameTitle(e.target.value)}
                required
              />

              <div className="form-control">
                <label className="label">
                  <span className="label-text font-semibold">遊戲描述</span>
                </label>
                <textarea
                  className="input-custom min-h-[100px]"
                  placeholder="輸入遊戲描述"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Input
                  label="難度"
                  type="select"
                  placeholder="選擇難度"
                />
                <Input
                  label="預估時間 (分鐘)"
                  type="number"
                  placeholder="30"
                />
              </div>
            </div>
          </Card>

          {pages.length > 0 && (
            <Card title="頁面設定" className="mt-6">
              <p className="text-base-content/70">
                選擇左側的頁面以編輯其內容
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

export default GameEditor
