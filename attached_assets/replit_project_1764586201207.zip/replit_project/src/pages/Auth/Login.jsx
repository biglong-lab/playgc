import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuthStore } from '../../stores/authStore'
import Card from '../../components/common/Card'
import Input from '../../components/common/Input'
import Button from '../../components/common/Button'

const Login = () => {
  const navigate = useNavigate()
  const { signIn, loading, error } = useAuthStore()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await signIn(email, password)
      navigate('/player')
    } catch (error) {
      console.error('Login error:', error)
    }
  }

  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-5xl font-black text-primary mb-2 font-english uppercase">
            賈村競技場
          </h1>
          <p className="text-base-content/70">實境遊戲系統</p>
        </div>

        <Card className="animate-slide-in-up">
          <h2 className="text-2xl font-bold mb-6 text-center">登入</h2>

          {error && (
            <div className="alert alert-error mb-4">
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="電子郵件"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <Input
              label="密碼"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <Button
              type="submit"
              variant="primary"
              fullWidth
              loading={loading}
            >
              登入
            </Button>
          </form>

          <div className="divider">或</div>

          <div className="text-center">
            <p className="text-sm text-base-content/70">
              還沒有帳號?{' '}
              <Link to="/register" className="text-primary hover:underline font-semibold">
                立即註冊
              </Link>
            </p>
          </div>
        </Card>
      </div>
    </div>
  )
}

export default Login
