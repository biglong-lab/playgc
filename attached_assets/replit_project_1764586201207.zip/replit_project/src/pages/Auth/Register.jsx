import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuthStore } from '../../stores/authStore'
import Card from '../../components/common/Card'
import Input from '../../components/common/Input'
import Button from '../../components/common/Button'

const Register = () => {
  const navigate = useNavigate()
  const { signUp, loading, error } = useAuthStore()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [validationError, setValidationError] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    setValidationError('')

    // 驗證密碼
    if (password !== confirmPassword) {
      setValidationError('密碼不一致')
      return
    }

    if (password.length < 8) {
      setValidationError('密碼至少需要 8 個字元')
      return
    }

    try {
      await signUp(email, password, { display_name: displayName })
      navigate('/player')
    } catch (error) {
      console.error('Register error:', error)
    }
  }

  return (
    <div className="min-h-screen bg-base-200 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-5xl font-black text-primary mb-2 font-english uppercase">
            賈村競技場
          </h1>
          <p className="text-base-content/70">實境遊戲系統</p>
        </div>

        <Card className="animate-slide-in-up">
          <h2 className="text-2xl font-bold mb-6 text-center">註冊</h2>

          {(error || validationError) && (
            <div className="alert alert-error mb-4">
              <span>{validationError || error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              label="顯示名稱"
              type="text"
              placeholder="您的名稱"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
            />

            <Input
              label="電子郵件"
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <Input
              label="密碼"
              type="password"
              placeholder="至少 8 個字元"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <Input
              label="確認密碼"
              type="password"
              placeholder="再次輸入密碼"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />

            <Button
              type="submit"
              variant="primary"
              fullWidth
              loading={loading}
            >
              註冊
            </Button>
          </form>

          <div className="divider">或</div>

          <div className="text-center">
            <p className="text-sm text-base-content/70">
              已經有帳號?{' '}
              <Link to="/login" className="text-primary hover:underline font-semibold">
                立即登入
              </Link>
            </p>
          </div>
        </Card>
      </div>
    </div>
  )
}

export default Register
