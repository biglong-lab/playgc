import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { gameService, sessionService } from '../../services/supabase'
import { useAuthStore } from '../../stores/authStore'
import Card from '../../components/common/Card'
import Button from '../../components/common/Button'
import Loading from '../../components/common/Loading'
import Badge from '../../components/common/Badge'

const GameLobby = () => {
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const [games, setGames] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedGame, setSelectedGame] = useState(null)
  const [teamName, setTeamName] = useState('')
  const [playerCount, setPlayerCount] = useState(1)

  useEffect(() => {
    loadGames()
  }, [])

  const loadGames = async () => {
    try {
      const data = await gameService.getPublishedGames()
      setGames(data)
    } catch (error) {
      console.error('Load games error:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleStartGame = async () => {
    if (!selectedGame || !teamName) return

    try {
      const session = await sessionService.createSession(
        selectedGame.id,
        teamName,
        playerCount
      )
      navigate(`/player/game/${session.id}`)
    } catch (error) {
      console.error('Start game error:', error)
      alert('開始遊戲失敗,請稍後再試')
    }
  }

  if (loading) {
    return <Loading fullScreen text="載入遊戲列表..." />
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* 標題 */}
      <div className="text-center mb-12 animate-fade-in">
        <h1 className="text-4xl md:text-5xl font-black text-primary mb-4 font-english uppercase tracking-wider">
          賈村競技場
        </h1>
        <p className="text-lg text-base-content/70">
          選擇一個遊戲,開始你的實境冒險
        </p>
      </div>

      {/* 遊戲列表 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        {games.map((game) => (
          <Card
            key={game.id}
            className={`cursor-pointer transition-all ${
              selectedGame?.id === game.id
                ? 'ring-4 ring-primary scale-105'
                : 'hover:scale-105'
            }`}
            onClick={() => setSelectedGame(game)}
          >
            {game.cover_image_url && (
              <img
                src={game.cover_image_url}
                alt={game.title}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
            )}
            <h3 className="text-xl font-bold mb-2">{game.title}</h3>
            <p className="text-sm text-base-content/70 mb-4 line-clamp-2">
              {game.description}
            </p>
            <div className="flex flex-wrap gap-2">
              <Badge variant="primary">{game.difficulty}</Badge>
              <Badge variant="info">{game.estimated_time} 分鐘</Badge>
              <Badge variant="secondary">最多 {game.max_players} 人</Badge>
            </div>
          </Card>
        ))}
      </div>

      {games.length === 0 && (
        <div className="text-center py-12">
          <p className="text-base-content/50 text-lg">目前沒有可用的遊戲</p>
        </div>
      )}

      {/* 開始遊戲表單 */}
      {selectedGame && (
        <Card className="max-w-2xl mx-auto animate-slide-in-up">
          <h2 className="text-2xl font-bold mb-6">開始遊戲: {selectedGame.title}</h2>
          
          <div className="space-y-4">
            <div className="form-control">
              <label className="label">
                <span className="label-text font-semibold">隊伍名稱 *</span>
              </label>
              <input
                type="text"
                placeholder="輸入你的隊伍名稱"
                className="input-custom"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
              />
            </div>

            <div className="form-control">
              <label className="label">
                <span className="label-text font-semibold">玩家人數</span>
              </label>
              <input
                type="number"
                min="1"
                max={selectedGame.max_players}
                className="input-custom"
                value={playerCount}
                onChange={(e) => setPlayerCount(parseInt(e.target.value))}
              />
            </div>

            <div className="flex gap-4 pt-4">
              <Button
                variant="secondary"
                fullWidth
                onClick={() => setSelectedGame(null)}
              >
                取消
              </Button>
              <Button
                variant="primary"
                fullWidth
                onClick={handleStartGame}
                disabled={!teamName}
              >
                開始遊戲
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  )
}

export default GameLobby
