import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useGameStore } from '../../stores/gameStore'
import { useAuthStore } from '../../stores/authStore'
import Loading from '../../components/common/Loading'
import Button from '../../components/common/Button'
import ProgressBar from '../../components/common/ProgressBar'

const GamePlay = () => {
  const { sessionId } = useParams()
  const navigate = useNavigate()
  const { user } = useAuthStore()
  const { 
    initializeSession, 
    currentSession, 
    currentGame,
    currentPage,
    score,
    loading 
  } = useGameStore()

  useEffect(() => {
    if (sessionId && user) {
      initializeSession(sessionId, user.id)
    }
  }, [sessionId, user])

  if (loading) {
    return <Loading fullScreen text="載入遊戲中..." />
  }

  if (!currentSession || !currentGame) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-base-content/70 mb-4">找不到遊戲場次</p>
          <Button onClick={() => navigate('/player')}>返回大廳</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-base-200">
      {/* 頂部資訊欄 */}
      <header className="bg-base-100 shadow-lg sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate('/player')}
                className="btn btn-ghost btn-sm"
              >
                ← 返回
              </button>
              <div>
                <h2 className="font-english font-bold text-lg">
                  {currentGame.title}
                </h2>
                <p className="text-sm text-base-content/70">
                  隊伍: {currentSession.team_name}
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="font-number text-2xl font-bold text-primary">
                {score}
              </div>
              <div className="text-xs text-base-content/70">積分</div>
            </div>
          </div>
          
          {/* 進度條 */}
          <div className="mt-4">
            <ProgressBar value={50} max={100} />
          </div>
        </div>
      </header>

      {/* 遊戲內容區 */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* 這裡會根據 currentPage 的類型渲染不同的頁面組件 */}
          <div className="bg-base-100 rounded-xl p-8 shadow-lg min-h-[400px]">
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4">遊戲頁面</h3>
              <p className="text-base-content/70 mb-8">
                頁面模組組件將在此處渲染
              </p>
              <p className="text-sm text-base-content/50">
                當前頁面 ID: {currentPage?.id || '未設定'}
              </p>
            </div>
          </div>

          {/* 操作按鈕 */}
          <div className="flex gap-4 mt-6">
            <Button variant="secondary" fullWidth>
              提示
            </Button>
            <Button variant="primary" fullWidth>
              繼續
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

export default GamePlay
