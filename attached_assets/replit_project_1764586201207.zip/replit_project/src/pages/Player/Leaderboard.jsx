import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { leaderboardService } from '../../services/supabase'
import Card from '../../components/common/Card'
import Loading from '../../components/common/Loading'
import Badge from '../../components/common/Badge'

const Leaderboard = () => {
  const { gameId } = useParams()
  const [leaderboard, setLeaderboard] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadLeaderboard()
  }, [gameId])

  const loadLeaderboard = async () => {
    try {
      const data = await leaderboardService.getLeaderboard(gameId, 50)
      setLeaderboard(data)
    } catch (error) {
      console.error('Load leaderboard error:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <Loading fullScreen text="載入排行榜..." />
  }

  return (
    <div className="min-h-screen bg-base-200 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-4xl font-black text-primary text-center mb-8 font-english uppercase">
          🏆 排行榜
        </h1>

        {leaderboard.length === 0 ? (
          <Card>
            <p className="text-center text-base-content/70">尚無排行榜記錄</p>
          </Card>
        ) : (
          <div className="space-y-4">
            {leaderboard.map((entry, index) => (
              <Card
                key={entry.id}
                className={`${
                  index === 0 ? 'ring-4 ring-primary' :
                  index === 1 ? 'ring-2 ring-secondary' :
                  index === 2 ? 'ring-2 ring-warning' : ''
                }`}
              >
                <div className="flex items-center gap-4">
                  {/* 排名 */}
                  <div className="flex-shrink-0">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center font-number font-black text-xl ${
                      index === 0 ? 'bg-primary text-base-100' :
                      index === 1 ? 'bg-secondary text-base-100' :
                      index === 2 ? 'bg-warning text-base-100' :
                      'bg-base-300'
                    }`}>
                      {index + 1}
                    </div>
                  </div>

                  {/* 隊伍資訊 */}
                  <div className="flex-1">
                    <h3 className="font-bold text-lg">{entry.team_name}</h3>
                    <p className="text-sm text-base-content/70">
                      完成時間: {Math.floor(entry.completion_time_seconds / 60)} 分 {entry.completion_time_seconds % 60} 秒
                    </p>
                  </div>

                  {/* 分數 */}
                  <div className="text-right">
                    <div className="font-number text-2xl font-bold text-primary">
                      {entry.total_score}
                    </div>
                    <div className="text-xs text-base-content/70">積分</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default Leaderboard
