import { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import Button from '../../components/common/Button'

const MapView = () => {
  const { sessionId } = useParams()
  const [userLocation, setUserLocation] = useState(null)

  useEffect(() => {
    // 取得使用者位置
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          })
        },
        (error) => {
          console.error('Geolocation error:', error)
        }
      )
    }
  }, [])

  return (
    <div className="min-h-screen bg-base-200">
      <header className="bg-base-100 shadow-lg p-4">
        <div className="container mx-auto flex items-center justify-between">
          <h2 className="font-english font-bold text-xl">地圖導航</h2>
          <Button variant="ghost" size="sm">
            聊天
          </Button>
        </div>
      </header>

      <main className="h-[calc(100vh-80px)]">
        {/* 地圖容器 - 需要整合 Leaflet */}
        <div className="w-full h-full bg-base-300 flex items-center justify-center">
          <div className="text-center">
            <p className="text-base-content/70 mb-4">
              地圖組件將在此處渲染
            </p>
            {userLocation && (
              <p className="text-sm text-base-content/50">
                當前位置: {userLocation.lat.toFixed(6)}, {userLocation.lng.toFixed(6)}
              </p>
            )}
          </div>
        </div>

        {/* 底部工具列 */}
        <div className="fixed bottom-0 left-0 right-0 bg-base-100 shadow-lg p-4">
          <div className="container mx-auto flex gap-4">
            <Button variant="secondary" fullWidth>
              📍 重新定位
            </Button>
            <Button variant="primary" fullWidth>
              🧭 指南針
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

export default MapView
