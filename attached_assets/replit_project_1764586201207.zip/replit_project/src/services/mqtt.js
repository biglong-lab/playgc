import mqtt from 'mqtt'

class MQTTService {
  constructor() {
    this.client = null
    this.connected = false
    this.subscribers = new Map()
  }

  // 連接 MQTT Broker
  connect() {
    if (this.client) {
      console.log('MQTT already connected')
      return Promise.resolve(this.client)
    }

    const brokerUrl = import.meta.env.VITE_MQTT_BROKER || 'wss://broker.hivemq.com:8884/mqtt'
    
    return new Promise((resolve, reject) => {
      this.client = mqtt.connect(brokerUrl, {
        clientId: `jiachun_web_${Math.random().toString(16).slice(3)}`,
        clean: true,
        connectTimeout: 4000,
        reconnectPeriod: 1000,
      })

      this.client.on('connect', () => {
        console.log('MQTT Connected')
        this.connected = true
        resolve(this.client)
      })

      this.client.on('error', (error) => {
        console.error('MQTT Connection Error:', error)
        this.connected = false
        reject(error)
      })

      this.client.on('message', (topic, message) => {
        this.handleMessage(topic, message)
      })

      this.client.on('close', () => {
        console.log('MQTT Connection Closed')
        this.connected = false
      })
    })
  }

  // 處理接收到的訊息
  handleMessage(topic, message) {
    try {
      const data = JSON.parse(message.toString())
      
      // 通知所有訂閱該主題的回調函數
      this.subscribers.forEach((callback, subscribedTopic) => {
        if (this.topicMatch(subscribedTopic, topic)) {
          callback(topic, data)
        }
      })
    } catch (error) {
      console.error('Error parsing MQTT message:', error)
    }
  }

  // 主題匹配 (支援萬用字元)
  topicMatch(pattern, topic) {
    const patternParts = pattern.split('/')
    const topicParts = topic.split('/')

    if (patternParts.length !== topicParts.length && !pattern.includes('#')) {
      return false
    }

    for (let i = 0; i < patternParts.length; i++) {
      if (patternParts[i] === '#') return true
      if (patternParts[i] !== '+' && patternParts[i] !== topicParts[i]) {
        return false
      }
    }

    return true
  }

  // 訂閱主題
  subscribe(topic, callback) {
    if (!this.client || !this.connected) {
      console.error('MQTT not connected')
      return
    }

    this.client.subscribe(topic, (error) => {
      if (error) {
        console.error('Subscribe error:', error)
        return
      }
      console.log(`Subscribed to ${topic}`)
      this.subscribers.set(topic, callback)
    })

    // 返回取消訂閱函數
    return () => this.unsubscribe(topic)
  }

  // 取消訂閱
  unsubscribe(topic) {
    if (!this.client) return

    this.client.unsubscribe(topic, (error) => {
      if (error) {
        console.error('Unsubscribe error:', error)
        return
      }
      console.log(`Unsubscribed from ${topic}`)
      this.subscribers.delete(topic)
    })
  }

  // 發布訊息
  publish(topic, message) {
    if (!this.client || !this.connected) {
      console.error('MQTT not connected')
      return Promise.reject(new Error('MQTT not connected'))
    }

    return new Promise((resolve, reject) => {
      const payload = typeof message === 'string' ? message : JSON.stringify(message)
      
      this.client.publish(topic, payload, { qos: 1 }, (error) => {
        if (error) {
          console.error('Publish error:', error)
          reject(error)
        } else {
          console.log(`Published to ${topic}:`, message)
          resolve()
        }
      })
    })
  }

  // 斷開連接
  disconnect() {
    if (this.client) {
      this.client.end()
      this.client = null
      this.connected = false
      this.subscribers.clear()
      console.log('MQTT Disconnected')
    }
  }

  // 檢查連接狀態
  isConnected() {
    return this.connected
  }
}

// 創建單例
const mqttService = new MQTTService()

// Arduino 設備相關的便捷方法
export const deviceService = {
  // 啟動設備
  async activateDevice(deviceId) {
    await mqttService.publish(`jiachun/devices/${deviceId}/command`, {
      command: 'activate',
      timestamp: Date.now()
    })
  },

  // 停用設備
  async deactivateDevice(deviceId) {
    await mqttService.publish(`jiachun/devices/${deviceId}/command`, {
      command: 'deactivate',
      timestamp: Date.now()
    })
  },

  // 重置設備
  async resetDevice(deviceId) {
    await mqttService.publish(`jiachun/devices/${deviceId}/command`, {
      command: 'reset',
      timestamp: Date.now()
    })
  },

  // 訂閱設備數據
  subscribeToDeviceData(deviceId, callback) {
    return mqttService.subscribe(`jiachun/devices/${deviceId}/data`, (topic, data) => {
      callback(data)
    })
  },

  // 訂閱設備狀態
  subscribeToDeviceStatus(deviceId, callback) {
    return mqttService.subscribe(`jiachun/devices/${deviceId}/status`, (topic, data) => {
      callback(data)
    })
  },

  // 訂閱所有設備
  subscribeToAllDevices(callback) {
    return mqttService.subscribe('jiachun/devices/+/data', (topic, data) => {
      const deviceId = topic.split('/')[2]
      callback(deviceId, data)
    })
  }
}

export default mqttService
