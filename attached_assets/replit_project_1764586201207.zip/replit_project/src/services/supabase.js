import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables')
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// 認證相關
export const authService = {
  // 註冊
  async signUp(email, password, metadata = {}) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: metadata
      }
    })
    if (error) throw error
    return data
  },

  // 登入
  async signIn(email, password) {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    if (error) throw error
    return data
  },

  // 登出
  async signOut() {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
  },

  // 取得當前使用者
  async getCurrentUser() {
    const { data: { user }, error } = await supabase.auth.getUser()
    if (error) throw error
    return user
  },

  // 監聽認證狀態變化
  onAuthStateChange(callback) {
    return supabase.auth.onAuthStateChange(callback)
  }
}

// 遊戲相關
export const gameService = {
  // 取得所有已發布的遊戲
  async getPublishedGames() {
    const { data, error } = await supabase
      .from('games')
      .select('*')
      .eq('status', 'published')
      .order('created_at', { ascending: false })
    
    if (error) throw error
    return data
  },

  // 取得單一遊戲詳情
  async getGameById(gameId) {
    const { data, error } = await supabase
      .from('games')
      .select('*, pages(*)')
      .eq('id', gameId)
      .single()
    
    if (error) throw error
    return data
  },

  // 創建遊戲
  async createGame(gameData) {
    const { data, error } = await supabase
      .from('games')
      .insert(gameData)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  // 更新遊戲
  async updateGame(gameId, updates) {
    const { data, error } = await supabase
      .from('games')
      .update(updates)
      .eq('id', gameId)
      .select()
      .single()
    
    if (error) throw error
    return data
  }
}

// 遊戲場次相關
export const sessionService = {
  // 創建遊戲場次
  async createSession(gameId, teamName, playerCount) {
    const { data, error } = await supabase
      .from('game_sessions')
      .insert({
        game_id: gameId,
        team_name: teamName,
        player_count: playerCount,
        status: 'playing'
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  // 取得場次資訊
  async getSession(sessionId) {
    const { data, error } = await supabase
      .from('game_sessions')
      .select('*, games(*)')
      .eq('id', sessionId)
      .single()
    
    if (error) throw error
    return data
  },

  // 更新場次分數
  async updateScore(sessionId, score) {
    const { data, error } = await supabase
      .from('game_sessions')
      .update({ score })
      .eq('id', sessionId)
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  // 完成場次
  async completeSession(sessionId, finalScore) {
    const { data, error } = await supabase
      .from('game_sessions')
      .update({ 
        status: 'completed',
        score: finalScore,
        completed_at: new Date().toISOString()
      })
      .eq('id', sessionId)
      .select()
      .single()
    
    if (error) throw error
    return data
  }
}

// 玩家進度相關
export const progressService = {
  // 取得玩家進度
  async getProgress(sessionId, userId) {
    const { data, error } = await supabase
      .from('player_progress')
      .select('*')
      .eq('session_id', sessionId)
      .eq('user_id', userId)
      .single()
    
    if (error && error.code !== 'PGRST116') throw error
    return data
  },

  // 儲存玩家進度
  async saveProgress(sessionId, userId, progressData) {
    const { data, error } = await supabase
      .from('player_progress')
      .upsert({
        session_id: sessionId,
        user_id: userId,
        ...progressData,
        updated_at: new Date().toISOString()
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  }
}

// 聊天相關
export const chatService = {
  // 發送訊息
  async sendMessage(sessionId, userId, message) {
    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        session_id: sessionId,
        user_id: userId,
        message
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  },

  // 訂閱聊天訊息
  subscribeToMessages(sessionId, callback) {
    return supabase
      .channel(`chat_${sessionId}`)
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages',
        filter: `session_id=eq.${sessionId}`
      }, callback)
      .subscribe()
  }
}

// 排行榜相關
export const leaderboardService = {
  // 取得遊戲排行榜
  async getLeaderboard(gameId, limit = 10) {
    const { data, error } = await supabase
      .from('leaderboard')
      .select('*')
      .eq('game_id', gameId)
      .order('total_score', { ascending: false })
      .limit(limit)
    
    if (error) throw error
    return data
  },

  // 新增排行榜記錄
  async addLeaderboardEntry(gameId, sessionId, teamName, totalScore, completionTime) {
    const { data, error } = await supabase
      .from('leaderboard')
      .insert({
        game_id: gameId,
        session_id: sessionId,
        team_name: teamName,
        total_score: totalScore,
        completion_time_seconds: completionTime
      })
      .select()
      .single()
    
    if (error) throw error
    return data
  }
}

// 檔案上傳相關
export const storageService = {
  // 上傳圖片
  async uploadImage(file, folder = 'uploads') {
    const fileExt = file.name.split('.').pop()
    const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`
    const filePath = `${folder}/${fileName}`

    const { data, error } = await supabase.storage
      .from('game-uploads')
      .upload(filePath, file)

    if (error) throw error
    
    // 取得公開 URL
    const { data: { publicUrl } } = supabase.storage
      .from('game-uploads')
      .getPublicUrl(filePath)

    return { path: filePath, url: publicUrl }
  },

  // 刪除檔案
  async deleteFile(filePath) {
    const { error } = await supabase.storage
      .from('game-uploads')
      .remove([filePath])

    if (error) throw error
  }
}

export default supabase
