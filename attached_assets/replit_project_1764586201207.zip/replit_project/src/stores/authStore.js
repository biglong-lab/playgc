import { create } from 'zustand'
import { authService } from '../services/supabase'

export const useAuthStore = create((set, get) => ({
  // 狀態
  user: null,
  session: null,
  loading: true,
  error: null,

  // 初始化認證狀態
  initialize: async () => {
    try {
      const user = await authService.getCurrentUser()
      set({ user, loading: false })

      // 監聽認證狀態變化
      authService.onAuthStateChange((event, session) => {
        set({ 
          user: session?.user || null,
          session: session
        })
      })
    } catch (error) {
      console.error('Auth initialization error:', error)
      set({ user: null, loading: false })
    }
  },

  // 註冊
  signUp: async (email, password, metadata) => {
    set({ loading: true, error: null })
    try {
      const data = await authService.signUp(email, password, metadata)
      set({ user: data.user, session: data.session, loading: false })
      return data
    } catch (error) {
      set({ error: error.message, loading: false })
      throw error
    }
  },

  // 登入
  signIn: async (email, password) => {
    set({ loading: true, error: null })
    try {
      const data = await authService.signIn(email, password)
      set({ user: data.user, session: data.session, loading: false })
      return data
    } catch (error) {
      set({ error: error.message, loading: false })
      throw error
    }
  },

  // 登出
  signOut: async () => {
    set({ loading: true, error: null })
    try {
      await authService.signOut()
      set({ user: null, session: null, loading: false })
    } catch (error) {
      set({ error: error.message, loading: false })
      throw error
    }
  },

  // 清除錯誤
  clearError: () => set({ error: null }),

  // 檢查是否已登入
  isAuthenticated: () => !!get().user,
}))
