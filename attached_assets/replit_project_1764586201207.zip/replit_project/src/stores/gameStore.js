import { create } from 'zustand'
import { sessionService, progressService } from '../services/supabase'

export const useGameStore = create((set, get) => ({
  // 狀態
  currentSession: null,
  currentGame: null,
  currentPage: null,
  inventory: [],
  variables: {},
  score: 0,
  loading: false,

  // 初始化遊戲場次
  initializeSession: async (sessionId, userId) => {
    set({ loading: true })
    try {
      // 取得場次資訊
      const session = await sessionService.getSession(sessionId)
      
      // 取得玩家進度
      const progress = await progressService.getProgress(sessionId, userId)
      
      set({
        currentSession: session,
        currentGame: session.games,
        currentPage: progress?.current_page_id || null,
        inventory: progress?.inventory || [],
        variables: progress?.variables || {},
        score: session.score || 0,
        loading: false
      })
    } catch (error) {
      console.error('Initialize session error:', error)
      set({ loading: false })
      throw error
    }
  },

  // 設定當前頁面
  setCurrentPage: (page) => {
    set({ currentPage: page })
    get().saveProgress()
  },

  // 新增道具
  addItem: (item) => {
    set((state) => ({
      inventory: [...state.inventory, item]
    }))
    get().saveProgress()
  },

  // 移除道具
  removeItem: (itemId) => {
    set((state) => ({
      inventory: state.inventory.filter(i => i.id !== itemId)
    }))
    get().saveProgress()
  },

  // 檢查是否擁有道具
  hasItem: (itemId) => {
    return get().inventory.some(i => i.id === itemId)
  },

  // 更新變數
  updateVariable: (key, value) => {
    set((state) => ({
      variables: { ...state.variables, [key]: value }
    }))
    get().saveProgress()
  },

  // 取得變數
  getVariable: (key, defaultValue = null) => {
    return get().variables[key] ?? defaultValue
  },

  // 增加分數
  addScore: async (points) => {
    const newScore = get().score + points
    set({ score: newScore })
    
    // 更新資料庫
    const sessionId = get().currentSession?.id
    if (sessionId) {
      await sessionService.updateScore(sessionId, newScore)
    }
  },

  // 儲存進度
  saveProgress: async () => {
    const state = get()
    const sessionId = state.currentSession?.id
    const userId = state.currentSession?.user_id

    if (!sessionId || !userId) return

    try {
      await progressService.saveProgress(sessionId, userId, {
        current_page_id: state.currentPage?.id,
        inventory: state.inventory,
        variables: state.variables
      })
    } catch (error) {
      console.error('Save progress error:', error)
    }
  },

  // 完成遊戲
  completeGame: async () => {
    const state = get()
    const sessionId = state.currentSession?.id
    const finalScore = state.score

    if (!sessionId) return

    try {
      await sessionService.completeSession(sessionId, finalScore)
      set({ currentSession: { ...state.currentSession, status: 'completed' } })
    } catch (error) {
      console.error('Complete game error:', error)
      throw error
    }
  },

  // 重置遊戲狀態
  reset: () => {
    set({
      currentSession: null,
      currentGame: null,
      currentPage: null,
      inventory: [],
      variables: {},
      score: 0,
      loading: false
    })
  }
}))
